

def createolx(message):
    try:
            from main import bot,requests,BeautifulSoup,randint,types,sqlite3
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            msg = message.text
            randItem = randint(111111,999999)
            URL = msg
            HEADERS = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36'
            }
            response = requests.get(URL, headers = HEADERS)
            soup = BeautifulSoup(response.content,'html.parser')
            items = soup.findAll('div', class_ = 'css-50cyfj')
            item_parse = []
            for item in items:
                item_parse.append({
                    'title': item.find('h1', class_ = "css-r9zjja-Text").get_text(strip = True),
                    "summa": item.find('h3', class_ = "css-okktvh-Text eu5v0x0").get_text(strip = True),
                    'imgp': item.find('img', class_ = "css-1bmvjcs")["src"]
                    })
                    

                for i in item_parse:
                    print(i['summa'])
                    d = i['summa']
                    s = d.split("грн.")
                    markup = types.InlineKeyboardMarkup(row_width=2)
                    but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openOlx_{randItem}")
                    markup.add(but)
                    
                    sql.execute(f'INSERT INTO FackeData (id,idFake,FackeAdress,FackePrace,FackeTitle,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{i["imgp"]}" ,"{s[0]}", "{i["title"]}" ,"olx",{0});')
                    db.commit()
                    bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🏷Название: {i['title']}\n💲Цена: {s[0]}\n🖼Фото: {i['imgp']}</b>",reply_markup=markup)
    except:
        bot.send_message(message.chat.id, "❌Ошибка!")