if __name__ == "__main__":
    # app.run(debug=True)
    from app import app
    from main import bot,threading
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port='80', debug=True, use_reloader=False)).start()
    print('flask started')
    bot.infinity_polling()