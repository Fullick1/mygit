def createizi(message):
    try:
        from main import bot,requests,BeautifulSoup,randint,types,sqlite3
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        msg = message.text
        randItem = randint(111111,999999)
        URL = msg
        HEADERS = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36'
        }
        response = requests.get(URL, headers = HEADERS)
        soup = BeautifulSoup(response.content,'html.parser')
        items = soup.findAll('div', class_ = 'ek-grid ek-grid_indent_xl')
        item_parse = []
        for item in items:
            item_parse.append({
                'title': item.find('h1', class_ = "ek-text ek-text_weight_medium ek-text_lheight_medium ek-text_wrap_break ek-text_size_h2").get_text(strip = True),
                "summa": item.find('span', class_ = "ek-text ek-text_weight_black ProductPrice__title--1gaRd").get_text(strip = True),
                'imgp': item.find('img', class_ = "ek-image ek-image_valign_top PhotoGallery__image--2HxpL")["src"]
                })
                

            for i in item_parse:
                print(i['summa'])
                d = i['summa']
                s = d.split("₴")
                markup = types.InlineKeyboardMarkup(row_width=2)
                but = types.InlineKeyboardButton("💢Открыть💢", callback_data=f"openIzi_{randItem}")
                markup.add(but)
                
                sql.execute(f'INSERT INTO FackeData (id,idFake,FakeAdress,FackePrace,FackeTitle,service,whovbiv) VALUES ({message.chat.id}, {randItem}, "{i["imgp"]}" ,"{s[0]}", "{i["title"]}" ,"izi",{0});')
                db.commit()
                bot.send_message(message.chat.id, f"<b>📦 Обьявление {randItem} созданно\n\n🏷Название: {i['title']}\n💲Цена: {s[0]}\n🖼Фото: {i['imgp']}</b>",reply_markup=markup)
    except:
        bot.send_message(message.chat.id, "❌Ошибка!")