#------------------------------------------------------------------#
token = "5414258498:AAEIH2vm6nI70KQQj6ShZF1o66TwZ2AQI8I" #bot token
botName = "ttbot111bot"
#------------------------------------------------------------------#
#------------------------------------------------------------------#
#chatID
chatAdmin =  '-871058683'#adminsChat
chatPays = '-871058683'#PaysChat
chatWorks = '-871058683'#WorkerChat
chatAlert = '-871058683'
chatCoder = '-871058683'

#------------------------------------------------------------------#
#chatLink 
chatWork = "https://t.me/+GFDgCtFL_4E2MDc9"
chatPay = "https://t.me/+GFDgCtFL_4E2MDc9"
#------------------------------------------------------------------#
#idAdministrator
#------------------------------------------------------------------#
#DOMAIN


dom = open(f'domain/Privat24.txt', 'r')
p = dom.read()
dom.close()
dprivat24 = f"{p}"


dom = open(f'domain/raif.txt', 'r')
p = dom.read()
dom.close()
draif = f'{p}'


dom = open(f'domain/OLX.txt', 'r')
p = dom.read()
dom.close()
dolx = f'{p}'


dom = open(f'domain/pumb.txt', 'r')
p = dom.read()
dom.close()
dpumb = f'{p}'


dom = open(f'domain/oschad.txt', 'r')
p = dom.read()
dom.close()
doschad = f'{p}'


dom = open(f'domain/pumb.txt', 'r')
p = dom.read()
dom.close()
dizi = f'{p}'























dom = open(f'domain/BlaBlaCarUa.txt', 'r')
p = dom.read()
dom.close()
dbbkua = f'{p}'


dom = open(f'domain/BusFor.txt', 'r')
p = dom.read()
dom.close()
dbusfor = f'{p}'

dom = open(f'domain/BusForRu.txt', 'r')
p = dom.read()
dom.close()
dbusforru = f'{p}'

dom = open(f'domain/Avito.txt', 'r')
p = dom.read()
dom.close()
davito = f'{p}'


dom = open(f'domain/Yola.txt', 'r')
p = dom.read()
dom.close()
dyola = f'{p}'


dom = open(f'domain/Yandex.txt', 'r')
p = dom.read()
dom.close()
dyandex = f'{p}'


dom = open(f'domain/BoxBerry.txt', 'r')
p = dom.read()
dom.close()
dboxbery = f'{p}'


dom = open(f'domain/CDEK.txt', 'r')
p = dom.read()
dom.close()
dcdek = f'{p}'


dom = open(f'domain/Sberbank.txt', 'r')
p = dom.read()
dom.close()
dsber = f'{p}'


dom = open(f'domain/PostaRussian.txt', 'r')
p = dom.read()
dom.close()
dpostarf = f'{p}'


dom = open(f'domain/BlablacarRu.txt', 'r')
p = dom.read()
dom.close()
dblablacarru = f'{p}'